import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath, pathToFileURL} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
let marked;
try { ({marked}=await import('marked')); }
catch(error) {
  const runtime=process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES;
  if(!runtime) throw new Error('请先在课程源码目录运行 npm install，再运行 npm run build。');
  ({marked}=await import(pathToFileURL(path.join(runtime,'marked/lib/marked.esm.js')).href));
}
marked.setOptions({gfm:true,breaks:false});
const out=path.join(root,'dist'),assets=path.join(out,'assets');
const esc=s=>String(s).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;');
const modules=[
 {title:'智能体的概念与结构',desc:'从一个工单开始，理解 Agent，并写出第一份 Spec。',short:'概念与结构'},
 {title:'多智能体系统的概念与结构',desc:'理解分工、协作契约、成本和故障处理。',short:'多智能体系统'},
 {title:'演化、能力、构建与工作流程',desc:'跟进前沿变化，动手运行可观察的 Agent 骨架。',short:'技术与构建'},
 {title:'案例分享与结课项目',desc:'把方法迁移到产品、研发和企业协作。',short:'案例与实践'}
];
const shortTitles=['先判断问题，再决定要不要 Agent','拆开智能体的核心结构','跟踪一次工具调用闭环','从用户故事写 Agent Spec','多 Agent 什么时候值得用','五种协作结构怎么选','状态、消息与协作协议','故障演练与人工决策','从回答问题到交付结果','上下文工程与 Harness','MCP、A2A 与 Skills','动手构建 Agent 骨架','产品经理的证据型调研','研发的代码交付 Agent','省市协作的工单平台','结课：可验收的 Agent'];
const outcomes=['方案选择卡','结构清单与状态','工具调用轨迹','可执行 Spec','架构选择记录','协作结构图','最小协作协议','故障演练记录','能力与边界表','上下文包与检查点','接入图与契约','离线实验与失败样本','一页决策简报','可评审代码任务','分层职责与授权图','六件项目交付物'];
const times=[20,25,30,35,25,30,30,30,25,30,30,60,30,30,30,180];
let lessons=[];
for(let m=1;m<=4;m++) {
 const raw=fs.readFileSync(path.join(root,`content/module${m}.md`),'utf8');
 for(const chunk of raw.split(/(?=^# )/m).filter(x=>x.startsWith('# '))) {
  const newline=chunk.indexOf('\n'),title=chunk.slice(2,newline).trim(),body=chunk.slice(newline+1).trim();
  const n=lessons.length+1,id=`lesson${String(n).padStart(2,'0')}`;
  lessons.push({n,id,title,body,module:m,short:shortTitles[n-1],outcome:outcomes[n-1],time:times[n-1]});
 }
}
if(lessons.length!==16)throw new Error(`expected 16 lessons, got ${lessons.length}`);
function md(raw,prefix='section'){
 let html=raw.replace(/:::answer\s*\n([\s\S]*?)\n:::/g,(_,answer)=>`\n<details class="answer"><summary>展开参考答案 · 先试着自己回答</summary><div class="answer-body">\n\n${marked.parse(answer)}\n</div></details>\n`);
 html=marked.parse(html);
 let count=0;html=html.replace(/<h([23])>/g,(_,n)=>`<h${n} id="${prefix}-${++count}">`);
 return html.replace(/<table>/g,'<div class="table-wrap" tabindex="0" role="region" aria-label="可横向滚动的数据表"><table>').replace(/<\/table>/g,'</table></div>').replace(/<pre>/g,'<div class="code-wrap"><pre>').replace(/<\/pre>/g,'</pre></div>');
}
function nav(current='',single=false){const href=l=>single?`#${l.id}`:`${l.id}.html`;return `<aside class="sidebar" id="course-nav" aria-label="课程目录"><div class="side-title">学习目录 <span class="muted">/ 16 课</span></div><a href="${single?'#overview':'index.html'}" ${current==='index'?'aria-current="page"':''}>课程导读与学习路线</a>${modules.map((m,i)=>`<div class="nav-module">${String(i+1).padStart(2,'0')} / ${m.short}</div>${lessons.slice(i*4,i*4+4).map(l=>`<a href="${href(l)}" ${l.id===current?'aria-current="page"':''}><span class="num">${String(l.n).padStart(2,'0')}</span><span>${esc(l.short)}</span></a>`).join('')}`).join('')}<div class="nav-module">配套材料</div><a href="${single?'#resources':'resources.html'}" ${current==='resources'?'aria-current="page"':''}>资料、模板与来源</a></aside>`;}
const footer=`<footer class="page-footer">AI Agent 实践课 · 内容核查 2026-09-21 · v1.0<br>工单与政策为虚构教学材料。演示与离线实验均明确标注能力边界。</footer>`;
function top(single=false){return `<a class="skip" href="#main">跳到正文</a><header class="topbar"><a class="brand" href="${single?'#overview':'index.html'}"><span class="brand-mark" aria-hidden="true">a_</span><span>AI Agent 实践课</span></a><nav class="top-links" aria-label="快捷导航"><a class="optional" href="${single?'#lesson12':'lesson12.html'}">动手实验</a><a href="${single?'#resources':'resources.html'}">学习资料</a><button class="menu-toggle" aria-controls="course-nav" aria-expanded="false">课程目录</button></nav></header>`;}
function page(title,body,current='',single=false){let css=single?`<style>${fs.readFileSync(path.join(assets,'style.css'),'utf8')}</style>`:'<link rel="stylesheet" href="assets/style.css">';let js=single?`<script>${fs.readFileSync(path.join(assets,'app.js'),'utf8')}</script>`:'<script src="assets/app.js" defer></script>';return `<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="color-scheme" content="light"><title>${esc(title)} · AI Agent 实践课</title><meta name="description" content="16课中文智能体教程：核心结构、多智能体、MCP/A2A、上下文工程、可运行实验与真实工程案例。"><link rel="icon" type="image/svg+xml" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'%3E%3Crect width='32' height='32' rx='7' fill='%23155ce7'/%3E%3Ctext x='6' y='22' font-family='monospace' font-size='22' fill='white'%3Ea%3C/text%3E%3C/svg%3E">${css}</head><body class="${single?'all-in-one':''}">${top(single)}<noscript><div class="noscript">正文与参考答案可以正常阅读。交互演示与移动端折叠目录需要 JavaScript；可使用页面中的课程链接。</div></noscript><div class="shell">${nav(current,single)}<main class="main ${current==='index'?'home-main':''}" id="main">${body}${footer}</main></div>${js}</body></html>`;}
function trace(id){return `<section class="widget" data-trace aria-labelledby="${id}-trace-title"><div class="widget-label">交互演示 / 事件轨迹</div><h3 id="${id}-trace-title">让工单助手走一步，看看发生了什么</h3><p>预设教学事件，不调用真实模型、不修改账户。事件数是叙事展示数；Python 实验的 <code>steps</code> 才是实际循环步数。</p><div class="control-row"><label for="${id}-scenario">选择场景<select id="${id}-scenario"><option value="success">正常交付草案</option><option value="tool-error">知识库不可用</option><option value="injection">工单夹带恶意指令</option><option value="budget">模拟预算耗尽</option><option value="denied-tool">提出未授权工具</option></select></label><button class="primary" data-next>执行下一步</button><button data-reset>重新开始</button></div><ol class="trace-list" aria-label="已发生的事件"></ol><div class="trace-status" role="status" aria-live="polite"></div></section>`;}
function cost(id){return `<section class="widget" data-cost aria-labelledby="${id}-cost-title"><div class="widget-label">交互演示 / 并行耗时</div><h3 id="${id}-cost-title">多开一个执行者，能省多少等待？</h3><p>仅两个中间任务可并行，其他步骤固定串行。这里计算耗时，不估算模型效果或价格。</p><div class="control-row"><label for="${id}-a">政策任务（秒）<input id="${id}-a" type="number" min="0" max="300" step="0.1" value="18"></label><label for="${id}-b">设备任务（秒）<input id="${id}-b" type="number" min="0" max="300" step="0.1" value="10"></label><label for="${id}-o">其他串行环节（秒）<input id="${id}-o" type="number" min="0" max="300" step="0.1" value="21"></label></div><output class="calc-result" style="display:block" aria-live="polite"></output><p class="meta">公式：依次 = A + B + 其他；并行 = max(A, B) + 其他。单 Agent 也可以并行调用工具，因此不能只凭这个结果决定采用多 Agent。</p></section>`;}
const diagrams={2:['agent-loop','先看责任边界：模型提出行动，执行器决定是否允许，观察结果进入下一轮。'],6:['multi-agent','主管与专家只是其中一种组合；专家意见必须带证据返回。'],8:['human-boundary','第二 AI 提供建议，人工核验与审批仍是独立条件。'],10:['context-pack','上下文是本轮看见的信息，状态和资料可以保存在窗口之外。'],11:['protocols','MCP 与 A2A 的职责示意；不是协议握手时序图。'],12:['build-eval','从 Spec 和样本开始，用失败记录决定下一次改动。']};
function fig(name,caption,single=false){const img=`<img class="diagram" src="assets/${name}.svg" alt="${esc(caption)}" loading="lazy">`;return `<figure class="figure">${single?img:`<a href="assets/${name}.svg" aria-label="打开原尺寸结构图">${img}</a>`}<figcaption>${esc(caption)} ${single?"结构图已内嵌，可缩放页面阅读。":"点击图可查看原尺寸。"}</figcaption></figure>`;}
function lessonHTML(l,single=false){let content=md(l.body,l.id);let insert='';if(diagrams[l.n])insert+=fig(...diagrams[l.n],single);if(l.n===3)insert+=trace(l.id);if(l.n===5)insert+=cost(l.id);if(insert){const h2s=[...content.matchAll(/<h2\b/g)];if(h2s.length>1){const index=h2s[1].index;content=content.slice(0,index)+insert+content.slice(index);}else content=insert+content;}
 if(l.n===12){content=`<div class="notice"><strong>实验文件：</strong> ${single?'完整 ZIP 中的 lab 目录包含 Python 源码、fixtures、示例报告和中文指南。':'<a href="downloads/agent-lab.zip" download>下载离线实验包</a> · <a href="downloads/model-adapter-guide.md" download>真实模型适配指南</a>'}</div>`+content;}
 const prev=l.n>1?lessons[l.n-2]:null,next=l.n<16?lessons[l.n]:null,href=x=>single?`#${x.id}`:`${x.id}.html`;
 return `<section id="${l.id}" aria-labelledby="${l.id}-title"><header class="article-header"><div class="eyebrow">模块 ${String(l.module).padStart(2,'0')} / ${modules[l.module-1].title}</div><h1 id="${l.id}-title">${esc(l.title)}</h1><div class="meta">建议学习 ${l.time} 分钟（含练习） · 本课产出：${esc(l.outcome)}</div><div class="article-toolbar"><a href="${single?'#overview':'index.html#curriculum'}">返回课程总览</a><span class="meta">${l.n} / 16</span></div></header><article class="article">${content}</article><nav class="pager" aria-label="前后课程">${prev?`<a href="${href(prev)}"><small>上一课</small>${esc(prev.short)}</a>`:'<span></span>'}${next?`<a class="next" href="${href(next)}"><small>下一课</small>${esc(next.short)}</a>`:`<a class="next" href="${single?'#resources':'resources.html'}"><small>继续实践</small>下载模板与实验资料</a>`}</nav></section>`;
}
function home(single=false){const link=n=>single?`#lesson${String(n).padStart(2,'0')}`:`lesson${String(n).padStart(2,'0')}.html`;return `<section id="overview"><div class="intro"><div><div class="eyebrow">从理解原理，到完成一次可验收的任务</div><h1>会行动的 AI，<br>怎样真正做好一件事？</h1><p class="lede">跟着一张 IT 工单，拆开智能体、组织协作、处理失败，再做出自己的 Agent。</p><div class="badges"><span class="badge">4 个模块 · 16 课</span><span class="badge">含参考答案</span><span class="badge">无需密钥的离线实验</span></div><div class="start-links"><a class="solid" href="${link(1)}">从第 1 课开始</a><a class="outline" href="${link(3)}">先看一次行动演示</a></div></div><figure class="figure"><img src="assets/agent-workbench.webp" width="1672" height="941" alt="机器人在工具工作台处理任务，人类工程师检查结果的原创教学插画"><figcaption class="image-caption">AI 生成的概念插画：行动需要工具，交付需要检查。</figcaption></figure></div><div class="notice"><strong>这门课怎么学？</strong><p>每课按“场景 → 原理 → 产物 → 练习 → 答案”展开。先读核心课，再沿角色路线深入。自学主课约 8–10 小时，结课项目另留 3–5 小时；90 分钟公开课与一天实训安排见讲师手册。</p><p class="meta">资料核查：2026-09-21。前沿内容附官方来源；协议与框架版本请在实际接入时重新核对。</p></div><div class="section-head"><h2>按你的工作选择路线</h2><span class="meta">第一次接触 Agent？先学 1–4 课。</span></div><div class="path-list"><div class="path"><strong>产品经理 / 业务设计</strong><p>判断场景，写清 Spec，设计证据与验收。</p><a href="${link(1)}">建议：1 → 4 → 5 → 8 → 13 → 16</a></div><div class="path"><strong>研发 / 技术实现</strong><p>工具契约、上下文、执行循环与失败处理。</p><a href="${link(2)}">建议：2 → 3 → 7 → 10 → 11 → 12 → 14</a></div><div class="path"><strong>负责人 / 平台建设</strong><p>组织分工、权限、成本与可追溯决策。</p><a href="${link(4)}">建议：4 → 5 → 6 → 8 → 15 → 16</a></div></div><div class="section-head" id="curriculum"><h2>课程目录</h2><span class="meta">从概念到案例，每一课都有具体产出</span></div>${modules.map((m,i)=>`<section class="module-card"><div class="module-head"><span class="module-number">${String(i+1).padStart(2,'0')}</span><div><h2>${m.title}</h2><p>${m.desc}</p></div></div><div class="lesson-grid">${lessons.slice(i*4,i*4+4).map(l=>`<a class="lesson-link" href="${link(l.n)}"><span class="num">${String(l.n).padStart(2,'0')}</span><span><strong>${esc(l.short)}</strong><small>${l.time} 分钟 · ${esc(l.outcome)}</small></span></a>`).join('')}</div></section>`).join('')}<div class="notice callout-warm"><strong>最后带走什么？</strong><p>一份 Agent Spec、一张系统图、一个可复现实验、成功与失败轨迹、评估报告，以及让别人能接手的说明。</p></div></section>`;}
const sources=[
['ReAct','2022-10-06（初稿）','经典行动循环研究','https://arxiv.org/abs/2210.03629'],
['Toolformer','2023-02-09','模型学习使用 API 的研究','https://arxiv.org/abs/2302.04761'],
['Building effective agents','2024-12-19','工作流与 Agent 的设计模式','https://www.anthropic.com/engineering/building-effective-agents'],
['Multi-agent research system','2025-06-13','公开调研系统实践与取舍','https://www.anthropic.com/engineering/multi-agent-research-system'],
['Context engineering','2025-09-29','上下文选择与管理','https://www.anthropic.com/engineering/effective-context-engineering-for-ai-agents'],
['Long-running agent harnesses','2025-11-26','跨会话交接与增量交付','https://www.anthropic.com/engineering/effective-harnesses-for-long-running-agents'],
['Demystifying evals for AI agents','2026-01-09','任务、试验、评分器和结果','https://www.anthropic.com/engineering/demystifying-evals-for-ai-agents'],
['MCP 2026-07-28 规范','2026-07-28（版本标识）','协议核心及版本边界','https://modelcontextprotocol.io/specification/2026-07-28'],
['MCP 变更记录','2026-07-28（版本标识）','与旧版初始化及会话机制的区别','https://modelcontextprotocol.io/specification/2026-07-28/changelog'],
['A2A 规范','动态文档，核查于 2026-09-21','任务、消息与产物','https://a2a-protocol.org/latest/specification/'],
['A2A v1.0.1 发布','发布行 2026-05-28；内嵌记录 05-26','规范页仍显示 1.0.0，仓库已有 1.0.1','https://github.com/a2aproject/A2A/releases/tag/v1.0.1'],
['Deep Agents','动态文档，核查于 2026-09-21','运行框架、上下文、子代理；v0.7 规划显式启用','https://docs.langchain.com/oss/python/deepagents/overview'],
['LangGraph Persistence','动态文档，核查于 2026-09-21','检查点与跨线程存储','https://docs.langchain.com/oss/python/langgraph/persistence'],
['Agent Skills','动态文档，核查于 2026-09-21','SKILL.md 目录格式与按需加载','https://agentskills.io/home'],
['Browser use','动态文档，核查于 2026-09-21','浏览器结构与视觉交互','https://platform.claude.com/docs/en/agents-and-tools/tool-use/browser-use-tool'],
['Computer use','动态文档，核查于 2026-09-21','桌面截图、鼠标和键盘','https://platform.claude.com/docs/en/agents-and-tools/tool-use/computer-use-tool']
];
const downloads=[['agent-lab.zip','离线实验包','Python 源码、12 项测试、5 个场景、fixtures 与示例输出。'],['Agent-Spec-template.md','Agent Spec 模板','完整填写示例 + 可复用空白模板。'],['evaluation-cases.jsonl','12 条设计级评估案例','用于设计验收；不是离线实验的输入接口。'],['decision-record-template.md','决策与交接模板','架构选择、人工判断、责任与证据。'],['instructor-guide.md','讲师手册','90 分钟公开课 + 一天实训时间表。'],['model-adapter-guide.md','模型适配指南','本地可运行接口示例与抽象回传序列。'],['course-spec.md','课程规划 Spec','受众、学习目标、范围与验收映射。'],['glossary.md','术语速查','遇到缩写时，先找到它负责什么。']];
function resources(single=false){return `<section id="resources"><header class="article-header"><div class="eyebrow">学习资料 / 证据与练习</div><h1>带着模板，开始你的项目</h1><p class="lede">先写清要交付什么，再用固定样本验证。资料和正文可以分开使用。</p></header><article class="article">${single?'<div class="notice">此单文件包含完整正文与交互。Python 实验、模板、课程源码和讲师手册位于配套完整 ZIP 中。</div>':`<div class="download-grid">${downloads.map(d=>`<a class="download-card" href="downloads/${d[0]}" download><strong>${d[1]} ↓</strong><small>${d[2]}</small></a>`).join('')}</div>`}<h2>本课中的“最新”指什么</h2><p>一手资料核查截止 <strong>2026-09-21</strong>。稳定概念写进主课，快速变化的版本信息单独标注。日期分为论文或文章发布日期、规范版本号、资料核查日，不互相替代。本文不承诺覆盖截至当天的全部行业进展。</p><p>MCP 规范采用固定版本链接；A2A 使用 1.0 系列表述，并保留规范页与发布记录的显示差异。框架功能不等于业务效果，公开案例改编会明确标记为教学设计。</p><h2>官方来源与进一步阅读</h2><ol class="source-list">${sources.map(s=>`<li><a href="${s[3]}">${esc(s[0])}</a><br><span class="meta">${esc(s[1])} · ${esc(s[2])}</span></li>`).join('')}</ol><h2>素材与使用说明</h2><p>课程正文、架构图和教学案例为本次编写的原创材料；工作台插画由 AI 生成。引用链接指向原作者材料，未复制其整篇内容或官方插图。你可以将交付的正文与原创素材编辑后放到个人网站；引用应保留来源与适用边界，外部资料继续遵循原作者的使用条款。</p><p>实验中的姓名、工单、政策和结果均为虚构或离线模拟，不应直接作为正式账户恢复规程。</p></article></section>`;}
fs.writeFileSync(path.join(out,'index.html'),page('课程导读',home(),'index'));
for(const l of lessons)fs.writeFileSync(path.join(out,`${l.id}.html`),page(l.title,lessonHTML(l),l.id));
fs.writeFileSync(path.join(out,'resources.html'),page('资料、模板与来源',resources(),'resources'));
let single=page('完整教程',home(true)+lessons.map(l=>'<hr class="chapter-divider">'+lessonHTML(l,true)).join('')+'<hr class="chapter-divider">'+resources(true),'index',true);
for(const file of fs.readdirSync(assets).filter(f=>/\.(webp|svg)$/.test(f))){const type=file.endsWith('.svg')?'image/svg+xml':'image/webp';const data=`data:${type};base64,${fs.readFileSync(path.join(assets,file)).toString('base64')}`;single=single.replaceAll(`assets/${file}`,data);}
fs.writeFileSync(path.join(root,'ai-agent-course.html'),single);
const book='# AI Agent 实践课：从概念到可验收的交付\n\n版本 v1.0 · 内容核查 2026-09-21\n\n'+modules.map((m,i)=>`- 模块${i+1}：${m.title}`).join('\n')+'\n\n阅读建议：基础概念先读1–4课；产品经理重点读4、5、8、13；研发重点读3、7、10–12、14；负责人重点读5、6、8、15。所有教学工单与政策均为虚构。\n\n'+lessons.map(l=>`# ${l.title}\n\n建议学习 ${l.time} 分钟（含练习）。本课产出：${l.outcome}。\n\n${l.body.replace(/:::answer\s*\n([\s\S]*?)\n:::/g,(_,a)=>`### 参考答案\n\n${a}`)}`).join('\n\n---\n\n')+'\n\n# 来源与核查记录\n\n'+sources.map(s=>`- [${s[0]}](${s[3]})：${s[1]}；${s[2]}。`).join('\n')+'\n';
fs.writeFileSync(path.join(root,'ai-agent-course.md'),book);
fs.writeFileSync(path.join(root,'content','sources.md'),'# 来源与核查记录\n\n核查日期：2026-09-21。动态文档未列出发布日期时不推断发布日期。\n\n'+sources.map(s=>`- [${s[0]}](${s[3]})：${s[1]}；${s[2]}。`).join('\n')+'\n');
fs.writeFileSync(path.join(root,'content','course-index.json'),JSON.stringify(lessons.map(({n,id,title,module,outcome,time})=>({n,id,title,module,outcome,time})),null,2));
console.log(JSON.stringify({pages:18,lessons:lessons.length,answers:(single.match(/class="answer"/g)||[]).length,standalone_bytes:Buffer.byteLength(single),markdown_characters:book.length}));
