# AI Agent 实践课 · 完整交付包

16课，4个模块，内容核查日期2026-09-21。正文、练习答案、原创图、交互演示、实验与讲师资料均已包含。

## 直接阅读

- 打开 `ai-agent-course.html`：单文件离线版，全部图片、正文和交互已内嵌。
- 打开 `dist/index.html`：多页网站版，含课程目录、16课和资料下载页。
- `ai-agent-course.md`：完整可编辑正文。每模块源文位于 `content/`。

使用当前 Chrome、Edge、Firefox 或 Safari 打开。所有内容和演示不需要账号、网络、API Key或CDN。单文件版的实验附件请使用本ZIP中的 `lab/` 和 `templates/`。

## 放到个人网站

将 **dist 目录里的全部内容** 上传到你网站的一个目录，例如 `project/agent-guide/`，访问该目录下的 `index.html`。保留 `assets/`、`downloads/` 和各课HTML的相对位置。不是只上传 index.html。

教程未修改或发布到你的现有网站。无需配置服务器运行代码；任何能托管静态文件的网站空间均可承载。若你使用博客系统，也可以导入 Markdown 并调整图片与下载路径。

站点没有分析追踪、登录、数据库或在线模型调用；交互均为浏览器本地教学演示。不要在公开网页放模型密钥。未来接真实模型时，需要独立服务端、授权、用量控制与重新评估。

## 配套实验

进入 `lab/` 后运行：

```bash
python3 agent_lab.py --scenario success
python3 agent_lab.py --scenario tool-error
python3 agent_lab.py --scenario injection
python3 agent_lab.py --scenario budget
python3 agent_lab.py --scenario denied-tool
python3 -m unittest -v
```

建议Python3.10+，无第三方依赖。失败演示退出码2是预期结果。`ScriptedPlanner` 是确定性规则模拟器；真实模型尚未接入。`lab/README.md` 和 `lab/model-adapter-guide.md` 解释完整边界。

## 文件结构

| 路径 | 用途 |
|---|---|
| `dist/` | 可直接上传的完整静态网站 |
| `ai-agent-course.html` | 单文件完整阅读版 |
| `ai-agent-course.md` | 完整Markdown正文 |
| `course-spec.md` | 课程目标、范围、结构和验收 |
| `content/module1.md` 至 `module4.md` | 逐模块原稿，含自定义答案标记 |
| `content/sources.md` | 官方来源、日期与核查说明 |
| `content/glossary.md` | 术语速查 |
| `templates/` | Spec、评估JSONL、决策模板、讲师手册 |
| `lab/` | 可运行离线实验、测试、fixtures、示例报告 |
| `scripts/build.mjs` | 从Markdown生成网站、单文件与总正文 |
| `scripts/diagrams.py` | 生成6张原创SVG结构图 |
| `validation-report.md` | 本次实际检查结果与未验证范围 |

## 修改后重新生成

已生成的网页可以直接用，不需要安装构建依赖。只有编辑课程源码后再生成，才需要 Node.js 20+ 与 `marked`：

```bash
npm install
npm run build
```

`marked` 固定为17.0.5。修改图的布局后，先运行 `python3 scripts/diagrams.py`，再构建。样式与交互分别在 `dist/assets/style.css` 与 `app.js`；本项目有意直接保留这两个静态源文件。

每课以一级标题开始，内部使用二级/三级标题。答案使用下列标记，构建后自动变为可展开答案：

```text
:::answer
参考答案正文
:::
```

若编辑实验或模板，请同步 `dist/downloads/` 的下载副本；实验ZIP需重新打包。`npm run build` 只生成页面和正文，不自动同步这些附件。

## 图片与引用

插画为AI生成，结构图为原创SVG；正文中的公开技术事实提供一手来源。公开实践与教学改编有明确区分。可以编辑本次交付的原创内容用于你的个人网站；外部来源保留原作者归属及使用条款。
