# 来源与核查记录

核查日期：2026-09-21。动态文档未列出发布日期时不推断发布日期。

- [ReAct](https://arxiv.org/abs/2210.03629)：2022-10-06（初稿）；经典行动循环研究。
- [Toolformer](https://arxiv.org/abs/2302.04761)：2023-02-09；模型学习使用 API 的研究。
- [Building effective agents](https://www.anthropic.com/engineering/building-effective-agents)：2024-12-19；工作流与 Agent 的设计模式。
- [Multi-agent research system](https://www.anthropic.com/engineering/multi-agent-research-system)：2025-06-13；公开调研系统实践与取舍。
- [Context engineering](https://www.anthropic.com/engineering/effective-context-engineering-for-ai-agents)：2025-09-29；上下文选择与管理。
- [Long-running agent harnesses](https://www.anthropic.com/engineering/effective-harnesses-for-long-running-agents)：2025-11-26；跨会话交接与增量交付。
- [Demystifying evals for AI agents](https://www.anthropic.com/engineering/demystifying-evals-for-ai-agents)：2026-01-09；任务、试验、评分器和结果。
- [MCP 2026-07-28 规范](https://modelcontextprotocol.io/specification/2026-07-28)：2026-07-28（版本标识）；协议核心及版本边界。
- [MCP 变更记录](https://modelcontextprotocol.io/specification/2026-07-28/changelog)：2026-07-28（版本标识）；与旧版初始化及会话机制的区别。
- [A2A 规范](https://a2a-protocol.org/latest/specification/)：动态文档，核查于 2026-09-21；任务、消息与产物。
- [A2A v1.0.1 发布](https://github.com/a2aproject/A2A/releases/tag/v1.0.1)：发布行 2026-05-28；内嵌记录 05-26；规范页仍显示 1.0.0，仓库已有 1.0.1。
- [Deep Agents](https://docs.langchain.com/oss/python/deepagents/overview)：动态文档，核查于 2026-09-21；运行框架、上下文、子代理；v0.7 规划显式启用。
- [LangGraph Persistence](https://docs.langchain.com/oss/python/langgraph/persistence)：动态文档，核查于 2026-09-21；检查点与跨线程存储。
- [Agent Skills](https://agentskills.io/home)：动态文档，核查于 2026-09-21；SKILL.md 目录格式与按需加载。
- [Browser use](https://platform.claude.com/docs/en/agents-and-tools/tool-use/browser-use-tool)：动态文档，核查于 2026-09-21；浏览器结构与视觉交互。
- [Computer use](https://platform.claude.com/docs/en/agents-and-tools/tool-use/computer-use-tool)：动态文档，核查于 2026-09-21；桌面截图、鼠标和键盘。
