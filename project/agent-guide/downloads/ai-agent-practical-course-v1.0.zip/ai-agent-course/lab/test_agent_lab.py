"""验收工作流边界，不声称评估真实大模型。"""
import copy
import unittest

from agent_lab import (
    Action, BadArguments, ScriptedPlanner, ToolDenied, ToolRegistry, ToolSpec,
    compose_draft, make_registry, run_lab, validate_draft,
)


class AgentLabTests(unittest.TestCase):
    def test_success_includes_verifiable_evidence_without_account_change(self):
        result = run_lab("success")
        self.assertEqual(result["status"], "completed")
        self.assertTrue(result["acceptance_report"]["passed"])
        self.assertFalse(result["uses_real_model"])
        self.assertEqual({item["clause_id"] for item in result["citations"]}, {"P1", "P2", "P3"})
        self.assertFalse(result["draft"]["account_changes_executed"])
        self.assertEqual([item["action"] for item in result["trace"]], ["tool", "tool", "compose", "validate", "finish"])

    def test_retrieval_failure_does_not_invent_policy_or_draft(self):
        result = run_lab("tool-error")
        self.assertEqual(result["status"], "blocked")
        self.assertIsNone(result["draft"])
        self.assertEqual(result["citations"], [])
        self.assertFalse(result["acceptance_report"]["passed"])
        self.assertEqual(result["trace"][-1]["error"]["type"], "RetrievalError")

    def test_injected_ticket_is_data_not_a_planner_instruction(self):
        result = run_lab("injection")
        self.assertEqual(result["status"], "completed")
        self.assertEqual(result["draft"], run_lab("success")["draft"])
        tool_names = [item["name"] for item in result["trace"] if item["action"] == "tool"]
        self.assertEqual(tool_names, ["read_ticket", "retrieve_policy"])
        observation = result["trace"][0]["observation"]
        self.assertEqual(observation["trust"], "untrusted_input")
        self.assertIn("reset_mfa", observation["data"]["description"])

    def test_unknown_tool_is_blocked(self):
        result = run_lab("denied-tool")
        self.assertEqual(result["status"], "denied")
        self.assertIsNone(result["draft"])
        self.assertEqual(result["trace"][-1]["error"]["type"], "ToolDenied")

    def test_registered_write_tool_cannot_execute_with_read_permission(self):
        calls = []
        registry = ToolRegistry({"read"})
        registry.register(ToolSpec("unsafe_demo", {}, "account:write", lambda _: calls.append(True)))
        with self.assertRaises(ToolDenied):
            registry.call("unsafe_demo", {})
        self.assertEqual(calls, [])

    def test_empty_permission_set_grants_nothing(self):
        registry = ToolRegistry(set())
        registry.register(ToolSpec("read", {}, "read", lambda _: {}))
        with self.assertRaises(ToolDenied):
            registry.call("read", {})

    def test_unexpected_and_wrong_type_arguments_are_rejected(self):
        registry = make_registry("success")
        for arguments in ({}, {"ticket_id": 2048}, {"ticket_id": ""}, {"ticket_id": "IT-2048", "admin": True}):
            with self.subTest(arguments=arguments):
                with self.assertRaises(BadArguments):
                    registry.call("read_ticket", arguments)

    def test_budget_stops_before_unfunded_action(self):
        result = run_lab("budget")
        self.assertEqual(result["status"], "budget_exhausted")
        self.assertEqual(result["limits"]["spent"], 2)
        self.assertEqual(len(result["trace"]), 2)
        self.assertIsNone(result["draft"])

    def test_zero_budget_never_calls_planner(self):
        class NeverCall:
            uses_real_model = False
            def next_action(self, state):
                raise AssertionError("预算为零时不应调用 Planner")
        result = run_lab(budget=0, planner=NeverCall())
        self.assertEqual(result["status"], "budget_exhausted")
        self.assertEqual(result["trace"], [])

    def test_infinite_planning_is_bounded_by_max_steps(self):
        class RepeatingPlanner:
            uses_real_model = False
            def next_action(self, state):
                return Action("tool", "read_ticket", {"ticket_id": "IT-2048"})
        result = run_lab(max_steps=3, budget=20, planner=RepeatingPlanner())
        self.assertEqual(result["status"], "max_steps")
        self.assertEqual(len(result["trace"]), 3)
        self.assertIsNone(result["draft"])

    def test_tampered_claim_fails_validation(self):
        registry = make_registry("success")
        state = {
            "ticket": registry.call("read_ticket", {"ticket_id": "IT-2048"}),
            "policy": registry.call("retrieve_policy", {"policy_id": "KB-MFA-03"}),
        }
        state["draft"] = compose_draft(state)
        for alteration in ("unsupported_text", "fake_citation", "identity_claim", "account_change"):
            candidate = copy.deepcopy(state)
            if alteration == "unsupported_text":
                candidate["draft"]["steps"][0]["text"] = "立即关闭 MFA"
            elif alteration == "fake_citation":
                candidate["draft"]["steps"][0]["citation"]["clause_id"] = "P999"
            elif alteration == "identity_claim":
                candidate["draft"]["identity_status"] = "已核验"
            else:
                candidate["draft"]["account_changes_executed"] = True
            with self.subTest(alteration=alteration):
                self.assertFalse(validate_draft(candidate)["passed"])

    def test_invalid_limits_are_rejected(self):
        for kwargs in ({"max_steps": 0}, {"budget": -1}, {"max_steps": True}):
            with self.subTest(kwargs=kwargs):
                with self.assertRaises(ValueError):
                    run_lab(**kwargs)


if __name__ == "__main__":
    unittest.main(verbosity=2)
