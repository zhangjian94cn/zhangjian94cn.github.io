import pytest
from fastapi.testclient import TestClient
from app.main import app, get_store


class MemoryStore:
    def __init__(self): self.rows = {}
    def ping(self): pass
    def create(self, values):
        row = {'id': len(self.rows) + 1, 'status': 'open', **values}
        self.rows[row['id']] = row
        return row.copy()
    def list(self): return list(self.rows.values())[::-1]
    def get(self, ticket_id): return self.rows.get(ticket_id)
    def update(self, ticket_id, status):
        if ticket_id not in self.rows: return None
        self.rows[ticket_id]['status'] = status
        return self.rows[ticket_id].copy()


@pytest.fixture
def client():
    store = MemoryStore()
    app.dependency_overrides[get_store] = lambda: store
    with TestClient(app) as c:
        yield c
    app.dependency_overrides.clear()


def test_create_read_update(client):
    response = client.post('/tickets', json={'title': '验证发布过程', 'priority': 'high'})
    assert response.status_code == 201
    ticket_id = response.json()['id']
    assert client.get(f'/tickets/{ticket_id}').json()['title'] == '验证发布过程'
    assert client.patch(f'/tickets/{ticket_id}', json={'status': 'done'}).json()['status'] == 'done'


@pytest.mark.parametrize('payload', [{'title': '  '}, {'title': 'ab'}, {'title': 'x' * 121},
                                      {'title': '有效工单', 'priority': 'urgent'}])
def test_invalid_input(client, payload):
    assert client.post('/tickets', json=payload).status_code == 422


def test_default_is_compatible_with_old_client(client):
    assert client.post('/tickets', json={'title': '旧客户端请求'}).json()['priority'] == 'normal'


def test_missing_ticket_and_invalid_status(client):
    assert client.get('/tickets/999').status_code == 404
    assert client.patch('/tickets/999', json={'status': 'done'}).status_code == 404
    assert client.patch('/tickets/1', json={'status': 'unknown'}).status_code == 422


def test_request_id_and_metric_labels(client):
    r = client.get('/tickets/987654', headers={'X-Request-ID': 'lab-test-20'})
    assert r.headers['x-request-id'] == 'lab-test-20'
    text = client.get('/metrics').text
    assert 'route="/tickets/{ticket_id}"' in text
    assert '987654' not in text


def test_live_does_not_depend_on_database():
    with TestClient(app) as c:
        assert c.get('/health/live').status_code == 200


def test_ready_without_config(monkeypatch):
    monkeypatch.delenv('DATABASE_URL', raising=False)
    with TestClient(app) as c:
        assert c.get('/health/ready').status_code == 503


def test_version_contains_nonsecret_environment(monkeypatch, client):
    monkeypatch.setenv('ENVIRONMENT', 'staging')
    monkeypatch.setenv('DATABASE_URL', 'do-not-expose-this-value')
    response = client.get('/version')
    assert response.json()['environment'] == 'staging'
    assert 'do-not-expose-this-value' not in response.text


def test_histogram_is_cumulative_and_infinite_bucket_matches_count(client):
    import re
    client.post('/tickets', json={'title': '验证延迟分桶'})
    metrics = client.get('/metrics').text
    pattern = r'ticketdesk_http_request_duration_seconds_bucket\{method="POST",route="/tickets",status="201",le="([^"]+)"\} (\d+)'
    buckets = re.findall(pattern, metrics)
    values = [int(value) for _, value in buckets]
    assert buckets[-1][0] == '+Inf'
    assert values == sorted(values)
    count = re.search(r'ticketdesk_http_request_duration_seconds_count\{method="POST",route="/tickets",status="201"\} (\d+)', metrics)
    assert values[-1] == int(count.group(1))
    assert values[-1] > 0
