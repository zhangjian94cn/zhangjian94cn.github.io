import sqlite3
import pytest
from extensions.async_demo import initialize, process


@pytest.fixture
def database():
    conn = sqlite3.connect(':memory:')
    initialize(conn)
    yield conn
    conn.close()


def event():
    return {'event_id': 'e-1', 'schema': 1, 'type': 'ticket.created', 'ticket_id': 1, 'category': 'billing'}


def test_redelivery_does_not_repeat_business_effect(database):
    assert process(database, event()) == 'applied'
    assert process(database, event()) == 'duplicate'
    assert database.execute('SELECT count FROM totals').fetchall() == [(1,)]


def test_failure_before_commit_rolls_back_marker_and_effect(database):
    with pytest.raises(RuntimeError):
        process(database, event(), fail_after_effect=True)
    assert database.execute('SELECT * FROM processed').fetchall() == []
    assert database.execute('SELECT * FROM totals').fetchall() == []
    assert process(database, event()) == 'applied'
    assert database.execute('SELECT count FROM totals').fetchone()[0] == 1


def test_reused_id_with_changed_content_is_rejected(database):
    process(database, event())
    with pytest.raises(ValueError, match='different content'):
        process(database, {**event(), 'category': 'account'})
    assert database.execute('SELECT category,count FROM totals').fetchall() == [('billing', 1)]


def test_unknown_schema_has_no_effect(database):
    with pytest.raises(ValueError, match='contract'):
        process(database, {**event(), 'schema': 2})
    assert database.execute('SELECT * FROM processed').fetchall() == []
