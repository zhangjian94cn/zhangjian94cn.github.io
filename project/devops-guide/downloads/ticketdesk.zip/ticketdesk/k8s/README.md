# Local Kubernetes lab

Requires Docker, kind, kubectl, a default StorageClass and enough resources for three local nodes. Record actual tool and node-image versions. A kind cluster is disposable; its local volumes are not disaster recovery storage.

From the TicketDesk root, on your own local machine:

```bash
docker build -t ticketdesk:dev .
kind create cluster --name ticketdesk --config k8s/kind.yaml
kind load docker-image ticketdesk:dev --name ticketdesk
kubectl --context kind-ticketdesk apply -f k8s/namespace.yaml
python3 scripts/k8s_secret.py
kubectl --context kind-ticketdesk -n ticketdesk create secret generic ticketdesk-db --from-env-file=.lab/k8s-db.env
kubectl --context kind-ticketdesk -n ticketdesk apply -f k8s/postgres.yaml
kubectl --context kind-ticketdesk -n ticketdesk rollout status statefulset/postgres --timeout=180s
kubectl --context kind-ticketdesk -n ticketdesk apply -f k8s/migration.yaml
kubectl --context kind-ticketdesk -n ticketdesk wait --for=condition=complete job/ticketdesk-migrate-v03 --timeout=120s
kubectl --context kind-ticketdesk apply -k k8s/base
kubectl --context kind-ticketdesk -n ticketdesk rollout status deployment/ticketdesk --timeout=180s
kubectl --context kind-ticketdesk -n ticketdesk port-forward service/ticketdesk 8001:80
```

In another terminal, `python3 scripts/smoke.py --url http://127.0.0.1:8001`. The secret-create command is intentionally one-time: on repeat runs inspect the existing secret rather than generating or overwriting database credentials. For later migrations choose a new Job name and the exact candidate image; do not edit the pod template of a completed Job.

`policies.yaml`, `hpa.yaml`, `gateway.yaml` and `operations.yaml` are separate exercises. They are not installed by the base kustomization. NetworkPolicy needs an enforcing CNI, HPA needs metrics, Gateway needs the compatible CRDs and an installed controller. Server-side dry-run and live checks are still required.

Dev/stage overlays contain the API only. Before using either, separately create the target namespace, Secret, database and completed migration in that namespace, or configure a prepared external DB. Do not point both environments at the same data by accident.

After backup and only when the entire local lab can be discarded, `kind delete cluster --name ticketdesk`. This destroys the lab cluster and its node-local data. Deleting only the API workload should not be confused with deleting the cluster or its PVCs.
