"""Bounded, closed-loop workload for loopback lab URLs. Creates fictional tickets."""
import argparse
from collections import Counter
from concurrent.futures import ThreadPoolExecutor
import json
import math
import time
from urllib.error import HTTPError, URLError
from urllib.parse import urlsplit
from urllib.request import Request, urlopen
import uuid

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--url', default='http://127.0.0.1:8000')
parser.add_argument('--requests', type=int, default=100)
parser.add_argument('--concurrency', type=int, default=4)
args = parser.parse_args()
parts = urlsplit(args.url)
if parts.scheme not in ('http', 'https') or parts.hostname not in ('localhost','127.0.0.1','::1'):
    parser.error('Use a loopback lab URL; remote load targets are outside this exercise')
if not 1 <= args.requests <= 2000 or not 1 <= args.concurrency <= 16:
    parser.error('Use 1..2000 requests and 1..16 concurrent workers')
run_id = uuid.uuid4().hex[:12]


def send(i):
    payload = json.dumps({'title': f'load-{run_id}-{i}', 'description': 'fictional bounded lab workload'}).encode()
    req = Request(args.url.rstrip('/')+'/tickets', data=payload,
                  headers={'Content-Type':'application/json','X-Request-ID':f'load-{run_id}-{i}'})
    start = time.monotonic()
    try:
        with urlopen(req,timeout=6) as response:
            response.read()
            status = response.status
    except HTTPError as e:
        status = e.code
    except (URLError, OSError):
        status = 0
    return status, time.monotonic()-start


start = time.monotonic()
with ThreadPoolExecutor(max_workers=args.concurrency) as executor:
    results = list(executor.map(send, range(args.requests)))
elapsed = time.monotonic()-start
latencies = sorted(value for _, value in results)
print(json.dumps({'run_id':run_id,'model':'closed-loop','requests':len(results),
                  'concurrency':args.concurrency,'elapsed_seconds':elapsed,
                  'completed_per_second':len(results)/elapsed,
                  'status_counts':dict(Counter(status for status,_ in results)),
                  'p95_seconds_nearest_rank':latencies[max(0,math.ceil(len(latencies)*0.95)-1)]},indent=2))
raise SystemExit(any(status != 201 for status,_ in results))
