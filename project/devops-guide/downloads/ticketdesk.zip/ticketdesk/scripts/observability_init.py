"""Add a separate local Grafana credential without overwriting existing settings."""
from pathlib import Path
import secrets
import lab

lab.init()
path = lab.ROOT / '.env'
text = path.read_text()
if not any(line.startswith('GRAFANA_PASSWORD=') for line in text.splitlines()):
    with path.open('a') as f:
        f.write(('' if text.endswith('\n') else '\n') + 'GRAFANA_PASSWORD=' + secrets.token_hex(24) + '\n')
    path.chmod(0o600)
    print('Added a separate local Grafana password. No credential was printed.')
else:
    print('Existing Grafana password preserved.')
