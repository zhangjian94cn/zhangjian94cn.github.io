"""Create local-only secret material for the documented kind lab; does not contact Kubernetes."""
from pathlib import Path
import os
import secrets

root = Path(__file__).resolve().parents[1]
folder = root / '.lab'
folder.mkdir(exist_ok=True)
path = folder / 'k8s-db.env'
try:
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
except FileExistsError:
    print('Existing local secret file preserved; no values printed.')
else:
    password = secrets.token_hex(24)
    with os.fdopen(descriptor, 'w') as f:
        f.write(f'password={password}\nurl=postgresql://ticketdesk:{password}@postgres:5432/ticketdesk\n')
    print('Created .lab/k8s-db.env with mode 0600; no values printed.')
