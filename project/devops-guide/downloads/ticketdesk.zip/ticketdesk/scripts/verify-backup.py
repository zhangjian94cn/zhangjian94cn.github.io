"""Restore the latest local backup to a NEW database and compare complete ticket rows."""
import json
import subprocess
from pathlib import Path
import lab

files = sorted((lab.ROOT / 'backups').glob('*.dump'))
if not files:
    raise SystemExit('Create a backup first')


def rows(name):
    sql = "SELECT coalesce(json_agg(t ORDER BY t.id), '[]'::json) FROM tickets t;"
    result = lab.compose('exec', '-T', 'db', 'psql', '-At', '-U', 'ticketdesk', '-d', name,
                         '-c', sql, capture_output=True, text=True)
    return json.loads(result.stdout.strip())


# This fixture comparison assumes writes are paused for the duration of the drill.
before = rows('ticketdesk')
name = 'verify_backup_' + __import__('secrets').token_hex(4)
lab.compose('exec', '-T', 'db', 'createdb', '-U', 'ticketdesk', name)
try:
    with files[-1].open('rb') as f:
        lab.compose('exec', '-T', 'db', 'pg_restore', '--exit-on-error', '-U', 'ticketdesk', '-d', name, stdin=f)
    restored = rows(name)
    if before != restored:
        raise SystemExit('Data differs. Check writes since the backup and schema/data contents.')
    print(json.dumps({'passed': True, 'verified_rows': len(restored), 'backup': files[-1].name}))
finally:
    lab.compose('exec', '-T', 'db', 'dropdb', '-U', 'ticketdesk', name)
