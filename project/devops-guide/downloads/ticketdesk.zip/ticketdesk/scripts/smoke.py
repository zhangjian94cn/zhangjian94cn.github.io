"""Standalone business smoke test. Supports a local API URL and an existing ticket."""
import argparse
from urllib.parse import urlsplit
import lab

parser = argparse.ArgumentParser()
parser.add_argument('--url', default='http://127.0.0.1:8000')
parser.add_argument('--ticket-id', type=int)
args = parser.parse_args()
parts = urlsplit(args.url)
if parts.scheme not in ('http','https') or not parts.netloc:
    parser.error('Supply an http(s) API URL')
lab.base_url = lambda: args.url.rstrip('/')
lab.check(args.ticket_id)
