"""Local-only lab controller. Uses Docker Compose and Python's standard library."""
import argparse
import json
import os
import re
import secrets
import shutil
import subprocess
import sys
import time
import urllib.error
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
STATE = ROOT / '.lab' / 'release.json'


def environment(extra=None):
    values = os.environ.copy()
    env_path = ROOT / '.env'
    if env_path.exists():
        for line in env_path.read_text().splitlines():
            if line.strip() and not line.startswith('#'):
                key, value = line.split('=', 1)
                values.setdefault(key, value)
    values.update(extra or {})
    return values


def compose(*args, extra=None, **kwargs):
    return subprocess.run(['docker', 'compose', '--project-name', 'devops-ticketdesk',
                           '--file', str(ROOT / 'compose.yaml'), *args], cwd=ROOT,
                          env=environment(extra), check=True, **kwargs)


def current_image():
    return json.loads(STATE.read_text())['image'] if STATE.exists() else environment().get('APP_IMAGE', 'ticketdesk:dev')


def record(image):
    STATE.parent.mkdir(exist_ok=True)
    payload = {'image': image, 'verified_at': datetime.now(timezone.utc).isoformat()}
    tmp = STATE.with_suffix('.tmp')
    tmp.write_text(json.dumps(payload, indent=2) + '\n')
    tmp.replace(STATE)


def base_url():
    port = int(environment().get('APP_PORT', '8000'))
    return f'http://127.0.0.1:{port}'


def request(path, method='GET', payload=None):
    data = None if payload is None else json.dumps(payload).encode()
    req = urllib.request.Request(base_url() + path, data=data, method=method,
                                 headers={'Content-Type': 'application/json', 'X-Request-ID': 'lab-check'})
    with urllib.request.urlopen(req, timeout=6) as response:
        return response.status, json.load(response)


def wait_ready():
    for _ in range(30):
        try:
            if request('/health/ready')[0] == 200:
                return
        except (urllib.error.URLError, OSError):
            pass
        time.sleep(1)
    raise RuntimeError('Readiness failed. Run: docker compose logs --tail 60 app')


def check(existing=None):
    wait_ready()
    status, version = request('/version')
    assert status == 200
    if existing is not None:
        assert request(f'/tickets/{int(existing)}')[0] == 200
    status, ticket = request('/tickets', 'POST', {'title': '交付验收工单', 'priority': 'high'})
    assert status == 201
    assert request(f"/tickets/{ticket['id']}")[1]['title'] == '交付验收工单'
    assert request(f"/tickets/{ticket['id']}", 'PATCH', {'status': 'done'})[1]['status'] == 'done'
    try:
        request('/tickets', 'POST', {'title': 'x'})
    except urllib.error.HTTPError as exc:
        assert exc.code == 422
    else:
        raise RuntimeError('Invalid input was incorrectly accepted')
    print(json.dumps({'passed': True, 'ticket_id': ticket['id'], 'version': version}, ensure_ascii=False))
    return ticket['id']


def init():
    p = ROOT / '.env'
    if p.exists():
        print('.env exists; preserved')
        return
    p.write_text('DB_PASSWORD=' + secrets.token_hex(24) + '\nAPP_PORT=8000\nDB_PORT=55432\n')
    p.chmod(0o600)
    print('Created local .env; no credential was printed')


def doctor():
    checks = {'python_3_12_or_newer': sys.version_info >= (3, 12),
              'git': bool(shutil.which('git')), 'docker_cli': bool(shutil.which('docker'))}
    if checks['docker_cli']:
        checks['compose_v2'] = subprocess.run(['docker', 'compose', 'version'], capture_output=True).returncode == 0
        checks['docker_daemon'] = subprocess.run(['docker', 'info'], capture_output=True).returncode == 0
    print(json.dumps(checks, indent=2))
    if not all(checks.values()):
        raise SystemExit(1)


def up(image=None):
    init()
    chosen = image or 'ticketdesk:dev'
    extra = {'APP_IMAGE': chosen, 'DB_HOST': 'db'}
    if image:
        compose('pull', 'app', extra=extra)
    else:
        compose('build', 'app', extra=extra)
    compose('up', '-d', '--wait', 'db', extra=extra)
    compose('run', '--rm', '--no-deps', 'migrate', extra=extra)
    compose('up', '-d', '--wait', '--no-build', '--no-deps', 'app', extra=extra)
    check()
    record(chosen)


def deploy(image):
    if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9._/:@-]*', image):
        raise SystemExit('Invalid image reference')
    if '@sha256:' in image or '/' in image:
        compose('pull', 'app', extra={'APP_IMAGE': image})
    compose('up', '-d', '--no-build', '--no-deps', 'app', extra={'APP_IMAGE': image, 'DB_HOST': 'db'})
    check()
    record(image)  # Only a healthy, business-checked candidate becomes the recovery target.


def fault():
    if not STATE.exists():
        raise SystemExit('Complete a healthy lab.py up before fault injection')
    compose('up', '-d', '--no-build', '--no-deps', 'app',
            extra={'APP_IMAGE': current_image(), 'DB_HOST': 'missing-lab-database'})
    print('Injected database hostname fault into the local app; recover with lab.py recover')


def recover():
    deploy(current_image())


def backup():
    folder = ROOT / 'backups'
    folder.mkdir(exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    path = folder / f'ticketdesk-{stamp}.dump'
    with path.open('wb') as f:
        compose('exec', '-T', 'db', 'pg_dump', '-U', 'ticketdesk', '-d', 'ticketdesk', '-Fc', stdout=f)
    if path.stat().st_size == 0:
        raise RuntimeError('Empty backup')
    print(path.relative_to(ROOT))


def restore(path):
    file = Path(path).resolve()
    if not file.is_file():
        raise SystemExit('Backup file does not exist')
    name = 'restore_' + datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')
    compose('exec', '-T', 'db', 'createdb', '-U', 'ticketdesk', name)
    with file.open('rb') as f:
        compose('exec', '-T', 'db', 'pg_restore', '--exit-on-error', '-U', 'ticketdesk', '-d', name, stdin=f)
    compose('exec', '-T', 'db', 'psql', '-U', 'ticketdesk', '-d', name, '-c', 'SELECT count(*) FROM tickets;')
    print(f'Restored into NEW database {name}; existing ticketdesk database was not overwritten.')
    print('Compare specific ticket IDs and business fields before considering this recovery verified.')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['doctor', 'init', 'up', 'check', 'deploy', 'fault', 'recover', 'down', 'backup', 'restore'])
    parser.add_argument('--image')
    parser.add_argument('--ticket-id', type=int)
    parser.add_argument('--file')
    args = parser.parse_args()
    if args.action == 'doctor': doctor()
    elif args.action == 'init': init()
    elif args.action == 'up': up(args.image)
    elif args.action == 'check': check(args.ticket_id)
    elif args.action == 'deploy':
        if not args.image: parser.error('deploy requires --image')
        deploy(args.image)
    elif args.action == 'fault': fault()
    elif args.action == 'recover': recover()
    elif args.action == 'down': compose('down')
    elif args.action == 'backup': backup()
    elif args.action == 'restore':
        if not args.file: parser.error('restore requires --file')
        restore(args.file)


if __name__ == '__main__':
    try:
        main()
    except (subprocess.CalledProcessError, RuntimeError, urllib.error.URLError, AssertionError) as error:
        print(f'Lab failed: {type(error).__name__}. Inspect the preceding step; no success was recorded.', file=sys.stderr)
        raise SystemExit(1)
