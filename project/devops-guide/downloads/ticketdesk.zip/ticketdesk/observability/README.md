# 本地观测实验

先按主项目 README 完成 `lab.py up` 和业务检查。所有以下命令从 TicketDesk 根目录运行；Compose 第一份文件决定相对挂载路径。

```bash
python3 scripts/observability_init.py
docker compose -f compose.yaml -f observability/compose.yaml up -d prometheus grafana alertmanager
```

Prometheus 为本机 9090，Grafana 为 3000，Alertmanager 为 9093。Grafana 用户 admin，密码为本机 `.env` 的独立 GRAFANA_PASSWORD；不要把文件内容提交或复制到报告。Alertmanager 的默认接收器不会发送外部通知。

可选追踪需要另建镜像：

```bash
docker build -f observability/Dockerfile.otel -t ticketdesk:otel-lab .
docker compose -f compose.yaml -f observability/compose.yaml up -d collector
docker compose -f compose.yaml -f observability/compose.yaml -f observability/otel-app.yaml up -d --no-build --no-deps app
python3 scripts/lab.py check
```

基础镜像 `ticketdesk:dev` 必须事先存在。Collector 仅将追踪导到本地诊断日志，不提供永久查询存储。临时 detailed 日志只用于合成数据，检查完整属性后恢复 basic。

结束时先用基础 `compose.yaml` 恢复原应用镜像并检查，再停止本次附加服务。不要加 `--volumes` 清理仍需保留的数据。所有组件的容器运行、采集、面板及通知仍需读者在本机验证；本版只完成配置解析与 API 指标测试。
