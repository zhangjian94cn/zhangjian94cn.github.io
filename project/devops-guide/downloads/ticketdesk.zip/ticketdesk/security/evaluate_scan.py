"""Evaluate Trivy-style vulnerability JSON with scoped, expiring exceptions. Synthetic fixtures are explicit."""
import argparse
from datetime import date
import json
from pathlib import Path

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('report',type=Path)
parser.add_argument('--exceptions',type=Path)
parser.add_argument('--expected-artifact',required=True)
parser.add_argument('--as-of',type=date.fromisoformat,default=date.today())
args=parser.parse_args()
report=json.loads(args.report.read_text())
if not isinstance(report,dict) or report.get('SchemaVersion') != 2:
    raise SystemExit('Unsupported or incomplete scan report')
if report.get('ArtifactName')!=args.expected_artifact:
    raise SystemExit('Report does not identify the expected artifact')
results=report.get('Results')
if not isinstance(results,list) or not results or any(not isinstance(r,dict) or not r.get('Target') for r in results):
    raise SystemExit('No supported scan targets; absence of evidence is not a clean scan')
exceptions=json.loads(args.exceptions.read_text()) if args.exceptions else []
blocked=[]
accepted=[]
for result in results:
    for item in result.get('Vulnerabilities') or []:
        if item.get('Severity') not in ('HIGH','CRITICAL'):continue
        match=next((e for e in exceptions if e.get('id')==item['VulnerabilityID'] and e.get('package')==item['PkgName'] and e.get('artifact')==args.expected_artifact),None)
        if match and match.get('owner') and match.get('reason') and date.fromisoformat(match['expires'])>=args.as_of:
            accepted.append(item['VulnerabilityID'])
        else:
            blocked.append({'id':item['VulnerabilityID'],'package':item['PkgName'],'severity':item['Severity']})
print(json.dumps({'artifact':args.expected_artifact,'allowed':not blocked,'blocked':blocked,'active_exceptions':accepted},indent=2))
raise SystemExit(bool(blocked))
