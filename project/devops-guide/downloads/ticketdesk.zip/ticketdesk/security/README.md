# Offline policy exercises

These checks evaluate supplied documents. They do not contact a registry, verify signatures, run a vulnerability scanner, or enforce cluster admission.

`check_workload.py` implements an intentionally small release profile: approved repository prefix, digest form, non-root user, bounded resources and selected container constraints. Fixture images are synthetic and must not be deployed.

```bash
python security/check_workload.py security/fixtures/workload-allowed.yaml --allowed-prefix ghcr.io/learning-team/
python security/check_workload.py security/fixtures/workload-denied.yaml --allowed-prefix ghcr.io/learning-team/
python security/evaluate_scan.py security/fixtures/scan-synthetic.json --expected-artifact lab://synthetic-ticketdesk --exceptions security/fixtures/exception-expired.json --as-of 2026-09-20
```

Expected exit codes are 0, 1 and 1. LAB-FINDING-001 and fictional-library are teaching fixtures, not claimed real vulnerabilities. Actual Trivy output must identify the exact intended artifact and be produced by a trusted job. Missing, malformed or untrusted reports must fail the release gate independently.

Real signature, provenance, vulnerability and admission tests remain separate checks described in chapters 41–44. A manifest policy can approve the shape of a digest reference without proving that image exists or is trustworthy.
