"""Small offline teaching policy. Not a replacement for Kubernetes admission or signature verification."""
import argparse
import json
import re
from pathlib import Path
import yaml

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('manifest', type=Path)
parser.add_argument('--allowed-prefix', required=True, help='Approved repository prefix ending in /')
args = parser.parse_args()
if not args.allowed_prefix.endswith('/'):
    parser.error('allowed-prefix must end in / to preserve a repository boundary')
errors = []
checked = 0
for doc in yaml.safe_load_all(args.manifest.read_text()):
    if not doc: continue
    kind = doc.get('kind')
    if kind == 'Pod': pod = doc['spec']
    elif kind == 'CronJob': pod = doc['spec']['jobTemplate']['spec']['template']['spec']
    elif kind in ('Deployment','StatefulSet','DaemonSet','Job','ReplicaSet'):
        pod = doc['spec']['template']['spec']
    else: continue
    checked += 1
    name = doc.get('metadata',{}).get('name','unnamed')
    def reject(reason): errors.append({'resource':name,'reason':reason})
    if any(pod.get(k,False) for k in ('hostNetwork','hostPID','hostIPC')): reject('Host namespaces are not allowed')
    if pod.get('automountServiceAccountToken',True): reject('Token automount must be explicitly disabled in this lab profile')
    if any('hostPath' in v for v in pod.get('volumes',[])): reject('hostPath is not allowed')
    security = pod.get('securityContext',{})
    if not pod.get('containers'): reject('At least one application container is required')
    for container in pod.get('initContainers',[])+pod.get('containers',[]):
        image = container.get('image','')
        if not image.startswith(args.allowed_prefix): reject('Image repository prefix is not allowed')
        if not re.fullmatch(r'.+@sha256:[0-9a-f]{64}',image): reject('An immutable sha256 image reference is required')
        own = container.get('securityContext',{})
        if not own.get('runAsNonRoot',security.get('runAsNonRoot',False)): reject('Non-root execution is required')
        if own.get('runAsUser',security.get('runAsUser')) == 0: reject('UID 0 is not allowed')
        if own.get('allowPrivilegeEscalation',True): reject('Privilege escalation must be disabled')
        if own.get('privileged',False): reject('Privileged containers are not allowed')
        if 'ALL' not in own.get('capabilities',{}).get('drop',[]): reject('Drop ALL capabilities')
        if own.get('capabilities',{}).get('add',[]): reject('Added capabilities require a separately reviewed profile')
        for field in ('requests','limits'):
            resources=container.get('resources',{}).get(field,{})
            if not all(k in resources for k in ('cpu','memory')): reject(f'CPU and memory {field} are required')
if not checked: errors.append({'resource':'input','reason':'No supported workload found'})
print(json.dumps({'checked_workloads':checked,'allowed':not errors,'findings':errors},indent=2))
raise SystemExit(bool(errors))
