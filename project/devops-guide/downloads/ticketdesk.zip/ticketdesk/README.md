# TicketDesk · DevOps 教学项目

与《DevOps 实战手册》v0.3 全书对应，默认从基础交付实验进入。运行于本机，使用虚构数据。应用没有登录系统，Compose 仅向 `127.0.0.1` 绑定端口；不要直接部署到公网。

## 快速运行

安装 Python 3.12+、Git、Docker Engine 或适用的桌面运行时、Compose v2。进入本目录：

```bash
python3 scripts/lab.py doctor
python3 scripts/lab.py up
python3 scripts/lab.py check
```

访问 `http://127.0.0.1:8000`。首次运行生成本机 `.env`，下载数据库镜像并构建应用。`.env` 不进入 Git。

## Python 接口测试

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements-dev.txt
.venv/bin/python -m pytest -q
```

接口测试替换数据库仓储，只验证 API 合约。真实 PostgreSQL、迁移和备份恢复由 Compose 实验验证，两者不能互相替代。

## 故障与恢复

```bash
python3 scripts/lab.py fault
curl -i http://127.0.0.1:8000/health/ready
python3 scripts/lab.py recover
python3 scripts/lab.py check
```

故障为本地应用注入错误数据库主机名；恢复使用最近通过业务检查的镜像和正常配置。不会自动撤销数据库迁移。停止后数据卷保留：

```bash
python3 scripts/lab.py down
```

只有确认删除本次实验数据时，才使用 `docker compose down --volumes`。

## 备份与验证

```bash
python3 scripts/lab.py backup
python3 scripts/verify-backup.py
```

校验时暂停写入。恢复发生在新建的临时数据库中，逐行比较工单后删除临时库。备份文件保存在本机 `backups/`。

## CI 文件放置

将本目录作为独立 Git 仓库根目录，`.github/workflows/ci.yml` 才会被 GitHub 识别。PR 检查使用只读令牌。发布工作流通过 `workflow_dispatch` 手动启动，且只允许 `main`；执行前在自己的仓库配置权限和保护规则。

## 版本与验证边界

Python 依赖使用确切版本。Docker 基础镜像目前使用教学候选标签；首次实际验证后按第 16 章固定镜像 digest。当前容器、真实 PostgreSQL 与 GitHub Actions 的运行状态见网站“版本与验证”页，不能从接口单测通过推导它们通过。

本项目是教学实现：短连接、100 条列表上限、无身份系统、进程内指标、简单迁移器。生产改造需要认证授权、连接池、分页、迁移发布策略、外部观测和容量验证。

## 进阶目录

- `infra/tofu` / `automation/ansible`：基础设施和 VM 配置。
- `k8s` / `helm` / `gitops`：集群、环境差异与声明式交付。
- `observability`：指标、仪表板、告警、Collector 和可选 Python 插桩。
- `security`：明确标注的合成样例与离线门禁。
- `ci/gitlab-ci.yml.example`：校验流程的 GitLab 迁移。
- `extensions`：可离线运行的幂等事务及 AI 规则桩评测，未接入 HTTP API。

本版 16 项 Python 测试通过。主线数据库仍需 Docker 实验验证，进阶组件不随 `lab.py up` 自动启动。按章节和目录说明准备额外环境；不把离线 YAML 渲染当集群运行通过。
