"""Local teaching service. No authentication: keep its ports on loopback."""
import json
import logging
import os
import re
import threading
import time
import uuid
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Literal

import psycopg
from fastapi import Depends, FastAPI, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse, PlainTextResponse
from pydantic import BaseModel, Field, field_validator

from .store import PostgresStore

try:
    from opentelemetry.trace import get_current_span
except ImportError:
    get_current_span = None  # Optional instrumentation is enabled only in the chapter 35 image.

app = FastAPI(title='TicketDesk · DevOps 教学项目', version='0.2.0')
logger = logging.getLogger('ticketdesk')
logger.setLevel(logging.INFO)
if not logger.handlers:
    logger.addHandler(logging.StreamHandler())
counts = Counter()
duration_buckets = Counter()
route_duration_sum = Counter()
route_duration_count = Counter()
BUCKETS = (0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1.0, 2.5, 5.0, 10.0)
duration_sum = 0.0
duration_count = 0
lock = threading.Lock()


class NewTicket(BaseModel):
    title: str = Field(min_length=3, max_length=120)
    description: str = Field(default='', max_length=2000)
    priority: Literal['low', 'normal', 'high'] = 'normal'

    @field_validator('title', mode='before')
    @classmethod
    def trim_title(cls, value):
        return value.strip() if isinstance(value, str) else value


class StatusChange(BaseModel):
    status: Literal['open', 'in_progress', 'done']


def get_store():
    dsn = os.environ.get('DATABASE_URL')
    if not dsn:
        raise HTTPException(503, 'database is not configured')
    return PostgresStore(dsn)


@app.middleware('http')
async def request_log(request: Request, call_next):
    global duration_sum, duration_count
    proposed = request.headers.get('x-request-id', '')
    request_id = proposed if re.fullmatch(r'[A-Za-z0-9_.-]{1,64}', proposed) else uuid.uuid4().hex
    started = time.monotonic()
    response = await call_next(request)
    elapsed = time.monotonic() - started
    route = request.scope.get('route')
    path = getattr(route, 'path', 'unmatched')
    with lock:
        counts[(request.method, path, response.status_code)] += 1
        duration_sum += elapsed
        duration_count += 1
        key = (request.method, path, response.status_code)
        route_duration_sum[key] += elapsed
        route_duration_count[key] += 1
        for boundary in BUCKETS:
            if elapsed <= boundary:
                duration_buckets[(*key, boundary)] += 1
    trace_fields = {}
    if get_current_span is not None:
        context = get_current_span().get_span_context()
        if context.is_valid:
            trace_fields = {'trace_id': format(context.trace_id, '032x'),
                            'span_id': format(context.span_id, '016x')}
    logger.info(json.dumps({'time': datetime.now(timezone.utc).isoformat(),
                           'request_id': request_id, 'method': request.method,
                           'route': path, 'status': response.status_code,
                           'duration_ms': round(elapsed * 1000, 2), **trace_fields}, ensure_ascii=False))
    response.headers['X-Request-ID'] = request_id
    return response


@app.exception_handler(psycopg.Error)
async def database_error(request: Request, exc: psycopg.Error):
    logger.warning(json.dumps({'event': 'database_unavailable', 'error_class': type(exc).__name__}))
    return JSONResponse(status_code=503, content={'detail': 'database unavailable'})


@app.get('/', response_class=HTMLResponse)
def page():
    return (Path(__file__).parent / 'index.html').read_text(encoding='utf-8')


@app.get('/health/live')
def live():
    return {'status': 'alive'}


@app.get('/health/ready')
def ready(store=Depends(get_store)):
    store.ping()
    return {'status': 'ready'}


@app.get('/version')
def version():
    return {'version': os.environ.get('APP_VERSION', 'dev'),
            'commit': os.environ.get('COMMIT_SHA', 'unrecorded'),
            'environment': os.environ.get('ENVIRONMENT', 'local')}


@app.get('/tickets')
def list_tickets(store=Depends(get_store)):
    return store.list()


@app.post('/tickets', status_code=201)
def create_ticket(ticket: NewTicket, store=Depends(get_store)):
    return store.create(ticket.model_dump())


@app.get('/tickets/{ticket_id}')
def get_ticket(ticket_id: int, store=Depends(get_store)):
    ticket = store.get(ticket_id)
    if ticket is None:
        raise HTTPException(404, 'ticket not found')
    return ticket


@app.patch('/tickets/{ticket_id}')
def change_status(ticket_id: int, change: StatusChange, store=Depends(get_store)):
    ticket = store.update(ticket_id, change.status)
    if ticket is None:
        raise HTTPException(404, 'ticket not found')
    return ticket


@app.get('/metrics', response_class=PlainTextResponse)
def metrics():
    with lock:
        lines = ['# HELP ticketdesk_http_requests_total Completed HTTP requests.',
                 '# TYPE ticketdesk_http_requests_total counter']
        for (method, path, status), value in sorted(counts.items()):
            lines.append(f'ticketdesk_http_requests_total{{method="{method}",route="{path}",status="{status}"}} {value}')
        lines += ['# TYPE ticketdesk_http_duration_seconds summary',
                  f'ticketdesk_http_duration_seconds_sum {duration_sum}',
                  f'ticketdesk_http_duration_seconds_count {duration_count}']
        lines.append('# TYPE ticketdesk_http_request_duration_seconds histogram')
        for (method, path, status), count in sorted(route_duration_count.items()):
            labels = f'method="{method}",route="{path}",status="{status}"'
            for boundary in BUCKETS:
                value = duration_buckets[(method, path, status, boundary)]
                lines.append(f'ticketdesk_http_request_duration_seconds_bucket{{{labels},le="{boundary}"}} {value}')
            lines.append(f'ticketdesk_http_request_duration_seconds_bucket{{{labels},le="+Inf"}} {count}')
            lines.append(f'ticketdesk_http_request_duration_seconds_count{{{labels}}} {count}')
            lines.append(f'ticketdesk_http_request_duration_seconds_sum{{{labels}}} {route_duration_sum[(method, path, status)]}')
    return PlainTextResponse('\n'.join(lines) + '\n', media_type='text/plain; version=0.0.4')
