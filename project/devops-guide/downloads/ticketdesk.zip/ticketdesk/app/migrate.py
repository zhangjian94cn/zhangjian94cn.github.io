"""Transactional, checksummed migrations guarded by a PostgreSQL advisory lock."""
import hashlib
import os
from pathlib import Path

import psycopg


def migrate():
    dsn = os.environ.get('DATABASE_URL')
    if not dsn:
        raise SystemExit('DATABASE_URL is required; no database changed')
    with psycopg.connect(dsn, connect_timeout=5) as conn:
        conn.execute("SET LOCAL lock_timeout = '5s'")
        conn.execute("SET LOCAL statement_timeout = '30s'")
        conn.execute('SELECT pg_advisory_xact_lock(842001)')
        conn.execute('CREATE TABLE IF NOT EXISTS schema_migrations '
                     '(name text PRIMARY KEY, checksum text NOT NULL, applied_at timestamptz DEFAULT now())')
        existing = dict(conn.execute('SELECT name, checksum FROM schema_migrations').fetchall())
        for path in sorted((Path(__file__).parent.parent / 'migrations').glob('*.sql')):
            payload = path.read_bytes()
            checksum = hashlib.sha256(payload).hexdigest()
            if path.name in existing:
                if existing[path.name] != checksum:
                    raise RuntimeError(f'Applied migration changed: {path.name}')
                continue
            conn.execute(payload.decode())
            conn.execute('INSERT INTO schema_migrations(name,checksum) VALUES (%s,%s)',
                         (path.name, checksum))
            print(f'applied {path.name}')
    print('schema ready')


if __name__ == '__main__':
    migrate()
