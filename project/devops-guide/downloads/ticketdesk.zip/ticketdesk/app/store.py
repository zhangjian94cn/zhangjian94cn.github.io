"""PostgreSQL repository. Connections are deliberately short-lived for teaching."""
import psycopg
from psycopg.rows import dict_row


class PostgresStore:
    def __init__(self, dsn: str):
        self.dsn = dsn

    def connect(self):
        return psycopg.connect(self.dsn, connect_timeout=3, row_factory=dict_row,
                              options='-c statement_timeout=3000')

    def ping(self):
        with self.connect() as conn:
            conn.execute('SELECT id, priority FROM tickets LIMIT 1')

    def create(self, values):
        with self.connect() as conn:
            return conn.execute(
                'INSERT INTO tickets(title,description,priority) VALUES (%s,%s,%s) RETURNING *',
                (values['title'], values['description'], values['priority'])).fetchone()

    def list(self):
        with self.connect() as conn:
            return conn.execute('SELECT * FROM tickets ORDER BY id DESC LIMIT 100').fetchall()

    def get(self, ticket_id):
        with self.connect() as conn:
            return conn.execute('SELECT * FROM tickets WHERE id=%s', (ticket_id,)).fetchone()

    def update(self, ticket_id, status):
        with self.connect() as conn:
            return conn.execute('UPDATE tickets SET status=%s WHERE id=%s RETURNING *',
                                (status, ticket_id)).fetchone()
