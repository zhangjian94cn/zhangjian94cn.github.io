"""Deterministic local release-gate stub. No model API, token usage or real AI quality claims."""
import argparse
import hashlib
import json
from pathlib import Path
import time

LABELS = {'billing', 'account', 'other'}


def classify(text):
    if not isinstance(text, str) or not 1 <= len(text) <= 2000:
        raise ValueError('Text must contain 1–2000 characters')
    text = text.lower()
    if any(word in text for word in ('invoice', 'refund', '发票', '退款')):
        return 'billing'
    if any(word in text for word in ('password', 'login', '密码', '登录')):
        return 'account'
    return 'other'


def evaluate(bundle_path, cases_path):
    bundle = json.loads(bundle_path.read_text())
    raw = cases_path.read_bytes()
    if bundle.get('model') != 'local-rules-v1' or set(bundle.get('labels', [])) != LABELS:
        raise ValueError('Unsupported release bundle')
    if hashlib.sha256(raw).hexdigest() != bundle.get('dataset_sha256'):
        raise ValueError('Dataset hash does not match release bundle')
    threshold = bundle.get('minimum_accuracy')
    if type(threshold) not in (int, float) or not 0 <= threshold <= 1:
        raise ValueError('Invalid quality threshold')
    cases = [json.loads(line) for line in raw.decode().splitlines() if line.strip()]
    if not cases:
        raise ValueError('Empty evaluation dataset')
    ids = set()
    wrong = []
    started = time.perf_counter()
    for case in cases:
        if not isinstance(case.get('id'), str) or not case['id'] or case['id'] in ids or case.get('expected') not in LABELS:
            raise ValueError('Invalid or duplicate case')
        ids.add(case['id'])
        if classify(case.get('text')) != case['expected']:
            wrong.append(case['id'])
    accuracy = (len(cases) - len(wrong)) / len(cases)
    return {'mode': 'local-rule-stub', 'total': len(cases), 'correct': len(cases)-len(wrong),
            'accuracy': accuracy, 'wrong_case_ids': wrong, 'allowed': accuracy >= threshold,
            'elapsed_ms': round((time.perf_counter()-started)*1000, 3), 'model_api_calls': 0}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--bundle', type=Path, required=True)
    parser.add_argument('--cases', type=Path, required=True)
    args = parser.parse_args()
    result = evaluate(args.bundle, args.cases)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    raise SystemExit(not result['allowed'])


if __name__ == '__main__':
    main()
