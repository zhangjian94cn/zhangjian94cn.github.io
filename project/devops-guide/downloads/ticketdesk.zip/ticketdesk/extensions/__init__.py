"""Optional local teaching extensions; not connected to the HTTP API."""
