# 可离线运行的扩展示例

从 TicketDesk 根目录运行，全部只使用本地数据，不连接主线 HTTP API：

```bash
python3 -m extensions.async_demo
python3 -m extensions.ai_demo --bundle extensions/ai_bundle.json --cases extensions/ai_cases.jsonl
```

异步示例使用 SQLite 内存事务，演示事件去重与分类计数一起提交。不能把它解释为已接入真实 broker，或外部邮件/支付严格一次。

AI 示例为确定性规则桩，不调用模型。八个教学案例用于验证摘要绑定、标签约束与质量门禁；不证明真实模型能力。修改样例后，必须在经评审的 bundle 中更新数据集摘要；降低阈值不是自动修复质量下降的方法。

开发依赖安装后执行 `python -m pytest -q tests/test_async.py` 可检查四个事务边界。第 54 和 56 专题解释接入主应用与真实外部系统前还需要哪些工作。
