"""Atomic idempotent consumer demonstration using one local SQLite transaction."""
import hashlib
import json
import sqlite3


def initialize(conn):
    conn.executescript('''
        CREATE TABLE IF NOT EXISTS processed(event_id TEXT PRIMARY KEY, payload_hash TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS totals(category TEXT PRIMARY KEY, count INTEGER NOT NULL);
    ''')


def process(conn, event, fail_after_effect=False):
    if event.get('schema') != 1 or event.get('type') != 'ticket.created':
        raise ValueError('Unsupported event contract')
    if not isinstance(event.get('event_id'), str) or not event['event_id']:
        raise ValueError('Missing stable event_id')
    if type(event.get('ticket_id')) is not int or event['ticket_id'] < 1:
        raise ValueError('Invalid ticket_id')
    if event.get('category') not in ('billing', 'account', 'other'):
        raise ValueError('Invalid category')
    fingerprint = hashlib.sha256(json.dumps(event, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
    with conn:
        # A write acquires the transaction lock before reading the existing marker.
        cursor = conn.execute('INSERT OR IGNORE INTO processed VALUES (?, ?)', (event['event_id'], fingerprint))
        if cursor.rowcount == 0:
            existing = conn.execute('SELECT payload_hash FROM processed WHERE event_id=?', (event['event_id'],)).fetchone()[0]
            if existing != fingerprint:
                raise ValueError('Same event_id with different content')
            return 'duplicate'
        conn.execute('INSERT INTO totals VALUES (?, 1) ON CONFLICT(category) DO UPDATE SET count=count+1', (event['category'],))
        if fail_after_effect:
            raise RuntimeError('Simulated failure before commit')
    return 'applied'


def demo():
    with sqlite3.connect(':memory:') as conn:
        initialize(conn)
        event = {'event_id': 'evt-001', 'schema': 1, 'type': 'ticket.created', 'ticket_id': 1, 'category': 'billing'}
        outcomes = [process(conn, event), process(conn, event)]
        print(json.dumps({'outcomes': outcomes, 'totals': dict(conn.execute('SELECT category,count FROM totals'))}))


if __name__ == '__main__':
    demo()
