# GitOps 声明样例

`project.yaml` 与 `application.yaml` 需要已运行的 Argo CD、可访问的环境仓库和目标命名空间。将两份文件的 `https://example.invalid/your-environment-repository.git` 换成你的同一个环境仓库；保留明确的源、目标与资源允许范围。

仓库根应含 `k8s/overlays/stage`。目标 `ticketdesk-stage` 先准备数据库、Secret 和迁移；overlay 只管理 API 相关对象。镜像从本地教学 tag 改成目标 registry 中已验证的 digest。

初始自动同步关闭，prune 和 selfHeal 均关闭。先完成人工同步、对象健康与业务检查，再按第 30 章分别演练漂移和同步策略；不要在未理解删除范围时打开 prune。

没有预置仓库凭据或集群管理员令牌。本版仅解析声明，未在 Argo CD 执行同步。
