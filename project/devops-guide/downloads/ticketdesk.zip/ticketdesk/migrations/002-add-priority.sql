ALTER TABLE tickets ADD COLUMN priority text NOT NULL DEFAULT 'normal'
    CHECK (priority IN ('low','normal','high'));
