terraform {
  required_version = ">= 1.8, < 2.0"
  required_providers {
    docker = {
      source  = "kreuzwerker/docker"
      version = "3.6.2"
    }
  }
}

provider "docker" {
  host = var.docker_host
}

variable "docker_host" {
  description = "Use the endpoint belonging to your local Docker context."
  type        = string
  default     = "unix:///var/run/docker.sock"
}

variable "lab_name" {
  type    = string
  default = "ticketdesk-iac"
  validation {
    condition     = can(regex("^ticketdesk-[a-z0-9-]+$", var.lab_name))
    error_message = "Use a ticketdesk-prefixed local lab name."
  }
}

resource "docker_network" "lab" {
  name     = var.lab_name
  internal = true
  labels {
    label = "tutorial.owner"
    value = "devops-handbook"
  }
}

resource "docker_volume" "lab" {
  name = "${var.lab_name}-data"
  labels {
    label = "tutorial.owner"
    value = "devops-handbook"
  }
}

output "network_name" {
  value = docker_network.lab.name
}

output "volume_name" {
  value = docker_volume.lab.name
}
