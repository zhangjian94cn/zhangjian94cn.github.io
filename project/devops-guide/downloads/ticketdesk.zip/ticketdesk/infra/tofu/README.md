# Local IaC lab

Creates an isolated Docker network and an initially empty volume. It does not deploy the application, connect a cloud account, or manage the existing Compose data volume.

Run `tofu init`, `tofu fmt -check`, `tofu validate`, then `tofu plan -out=lab.tfplan`. Inspect the plan before `tofu apply lab.tfplan`. Keep the generated `.terraform.lock.hcl`; it contains provider checksums, not resource state.

Docker Desktop may use a different endpoint: inspect your own `docker context inspect` output and set `TF_VAR_docker_host` accordingly. Do not publish the Docker socket over an unauthenticated network.

Destroy only these lab resources after confirming no container or data depends on them: inspect `tofu plan -destroy`, then run `tofu destroy` interactively. State files and saved plans may contain sensitive resource data and are excluded from Git.

Provider version is exact; no provider checksum lock is fabricated. The checked-in baseline has not been applied to a Docker daemon. Chapters 22 and 23 distinguish parser checks, provider validation, state operations and actual resource behavior.
