# 版本与验证

内容版本为 **v0.3 完整阅读版**，资料核对与本次检查日期为 **2026-09-20**。48 章主线、8 个专题及答案均已收录。本页明确区分正文、离线检查和真实环境实验。

## 已实际执行

| 对象 | 结果 | 证明的范围 |
| --- | --- | --- |
| Python 测试 | 16 项通过，2 项上游弃用提示 | 12 项 API/指标/环境标识测试；4 项 SQLite 幂等、事务回滚与拒绝测试 |
| 离线示例检查 | 23 项通过 | Python 编译、36 份 YAML 解析、策略正反例、扫描例外与缺失报告、AI 桩评测、脚手架、Helm 和 Kustomize |
| Helm | 3.19.0 lint 与渲染通过；缺少 Secret 参数被拒绝 | Chart 模板层，未执行安装或连接集群 |
| Kustomize | kubectl 1.34.0 内置渲染器生成 dev/stage 配置 | 命名空间、副本、环境标识与 Service selector 一致，未提交 API |
| OpenTelemetry 可选依赖 | 在基础依赖约束下完成解析并记录确切版本 | 依赖解析，不是镜像安装、自动插桩或真实导出验收 |
| 网站 | 构建、页面/锚点/下载检查及 JS 语法检查 | 结构与引用；浏览器视觉和交互另行验收 |
| 外部引用 | Actions 完整 SHA、选定组件标签及官方资料核对 | 来源与选定版本存在性，不代表集成运行成功 |

离线检查使用虚构扫描发现和明确标注的假 digest，验证规则是否生效；没有把它们当作真实制品的安全证明。AI 分类使用本地规则桩，八个样例仅验证交付门禁，不代表模型质量。

检查细节随源码保存在 `VALIDATION.md`、`validation/offline-examples.json` 和 `validation/site-check.json`。弃用提示来自当前 FastAPI/Starlette 测试依赖接口，升级时需要处理并重跑。

## 仍需真实环境验证

编写环境没有可用 Docker daemon、PostgreSQL 或实验集群，因此未执行镜像构建、Compose、真实迁移/锁/备份恢复、OpenTofu provider 初始化与 apply、Ansible SSH、Kubernetes 调度/网络/存储、Argo CD、真实指标采集、告警送达或压测。

也未在你的 GitHub/GitLab、云账户、内网 registry 中执行托管 CI、推送与部署；未生成或验证真实候选制品的扫描、SBOM 和签名；未调用真实模型。对应配置和正文均保留前提、预期与验收办法。

本静态项目未进行浏览器视觉和交互自动化验收。发布检查覆盖 HTML 结构、链接、附件与脚本语法；个人站接入后需验证桌面和手机的菜单、搜索、复制、打印及 SLO 计算器。

## 工具与依赖基线

| 对象 | 本版设置 | 使用状态 |
| --- | --- | --- |
| Python | 实测 3.12.14，基础实验要求 3.12+ | 其他版本待复现 |
| FastAPI / psycopg / pytest | 0.141.1 / 3.3.6 / 9.1.1 | 包已安装，API 与 SQLite 测试已运行；PostgreSQL 未运行 |
| Uvicorn | 0.53.0 | 已安装，容器路径待测 |
| 基础镜像 | python:3.12-slim、postgres:17、nginx:stable-alpine | 教学候选标签，需真实获取后锁定 digest |
| OpenTofu Docker provider | kreuzwerker/docker 3.6.2 | 标签核对；未生成锁文件或连接 daemon |
| Helm / kubectl | 3.19.0 / 1.34.0 | 仅本次离线渲染工具，不作为生产集群版本建议 |
| Envoy Gateway | 官方 quickstart 核对为 v1.9.1 | 安装候选；需检查你的集群兼容性 |
| Prometheus / Grafana | v3.5.0 / 12.2.0 | 选定镜像候选，真实运行待测 |
| Alertmanager / OTel Collector | v0.28.1 / 0.137.0 | 本地实验配置，运行待测；无外部通知接收者 |
| OTel Python | SDK 1.44.0、instrumentation 0.65b0 | 解析后的可选依赖集，插桩运行待测 |
| Markdown | marked 17.0.5 | 确切版本用于网站生成 |

版本用于说明这次材料的输入，不宣称全部是最新、长期支持或推荐的生产组合。镜像、平台默认值、受支持版本和工具生命周期会变化，开始真实实验前按官方资料复核。

## 距离完整实验验收还有什么

需要在干净环境执行全部主线、由另一个独立环境复现、保留托管 CI 与实际集群证据；补逐章/阶段起终点快照、旧二进制与新数据库兼容矩阵、迁移失败与恢复时间；完成浏览器验收和读者试读。

当前基线已包含 priority 功能，正文把它作为分析案例；独立实现练习为 status 查询过滤。异步和 AI 示例尚未接到 API；服务网格、Java 和跨云部分是有明确前提的扩展案例。综合项目必须保存自己的开始与结束提交，并逐项记录执行范围。

## 来源与维护

范围参考 [DevOps Roadmap](https://github.com/milanm/DevOps-Roadmap)，章节就近链接官方资料，包括 Kubernetes、OpenTofu、Ansible、Prometheus、OpenTelemetry、PostgreSQL、DORA、SLSA 及相关平台文档。正文案例、计算与练习自行组织，模拟数据有明确标识。

用户提供的 [Git 教程参考页](https://zhangjian94cn.top/project/git-guide/index.html) 在最初读取时受限，未能确认其实际布局，因此当前阅读界面独立设计，不声称逐像素复刻。

修订时记录受影响章节、上游依据、原因与重跑检查。已有通过记录不能自动覆盖新版本；没运行的项目继续写“待验证”。
