# 配套项目与资料

这一页收集可以下载、运行和继续维护的材料。正文中的命令以同一份 TicketDesk 项目为基准；下载后先阅读 README 和验证范围，再选择本章实验。

## 下载入口

| 文件 | 内容 | 适合谁 |
| --- | --- | --- |
| [TicketDesk 项目](downloads/ticketdesk.zip) | API、页面、SQL 迁移、测试、Docker/Compose、CI、实验脚本 | 跟做实验的读者 |
| [工程记录模板](downloads/templates.zip) | 11 份模板：需求、PR、ADR、发布、运行、复盘、学习、生产评审、综合项目与 AI 评审 | 记录实践结果的读者 |
| [教程 Markdown](downloads/devops-guide-markdown.zip) | 48 章主线、8 专题、答案、导读与完整 Spec | 离线阅读或编辑正文 |
| [网站可维护源码](downloads/devops-guide-source.zip) | 内容、样式、交互、生成与检查工具、示例项目 | 持续维护网站的作者 |
| [静态网站部署包](downloads/devops-guide-deploy.zip) | 可直接上传的 devops-guide 目录 | 接入个人网站 |

所有下载不包含本地密码、实验数据库、备份数据或 Python 虚拟环境。Markdown 中的章节链接采用生成后的网站路径；离线阅读时可按文件编号查找，完整链接体验使用静态网站包。

## 运行工单服务

解压项目，进入 `ticketdesk/`，确认已安装 Python 3.12+、Git、Docker 与 Compose v2：

```bash
python3 scripts/lab.py doctor
python3 scripts/lab.py up
python3 scripts/lab.py check
```

应用地址为 `http://127.0.0.1:8000`。`up` 首次生成本机配置并准备数据库，`check` 会创建、查询和更新一张验收工单，并确认无效输入被拒绝。每次检查会增加验收记录，这是写入实验，不是纯读取探测。

项目只绑定本机端口，使用虚构数据。真实环境需要认证授权、访问边界、配置管理和对应验证，不能直接把教学页面开放给公众使用。

## 没有 Docker 时能验证什么

可以运行 API 合约测试，学习输入校验、状态码和业务接口。它们替换数据库仓储，不需要本机 PostgreSQL：

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements-dev.txt
.venv/bin/python -m pytest -q
```

不能因此宣称 SQL、事务、镜像、网络、持久卷和真实恢复已经通过。开发环境缺少某个条件时，学习记录应说明已完成与未完成的部分。

## 项目结构与阅读顺序

| 路径 | 建议首先阅读的内容 |
| --- | --- |
| `app/main.py` | 输入模型、接口、健康检查、日志与指标 |
| `app/store.py` | 参数化 SQL、事务与连接超时 |
| `app/migrate.py` | 有序迁移、校验和、事务和锁 |
| `tests/test_api.py` | 内存替身与 API 合约边界 |
| `scripts/lab.py` | 环境启动、验证、故障、恢复、备份 |
| `scripts/verify-backup.py` | 恢复到新库并对比完整工单 |
| `compose.yaml` | 服务、网络、卷、配置与健康 |
| `.github/workflows/` | PR 检查与手动候选发布 |

GitHub 工作流必须位于仓库根目录下的 `.github/workflows/`。教程源码仓库中的项目放在 `examples/ticketdesk/`，这一层级中的工作流不会自动被 GitHub 执行。跟做时以下载项目目录为独立仓库根目录。

## 数据保留与实验清理

```bash
python3 scripts/lab.py down
```

这会停止并移除本项目容器和网络，保留命名卷。备份保存在本机 `backups/`，配置位于 `.env`，最近验证通过的镜像位于 `.lab/release.json`。

只有你明确不再需要实验数据时，才手工选择删除卷；普通排障不要求清空数据库。CI 工作流最后删除自己的临时数据，与本地保留学习成果的流程不同。

## 进阶资料如何进入

| 目录 | 使用章节与边界 |
| --- | --- |
| `infra/tofu/`、`automation/ansible/` | 22—24；本地 Docker 资源和 Linux VM 配置，需要相应运行环境 |
| `k8s/`、`helm/`、`gitops/` | 25—32；基础声明、双环境、网关、灰度与 GitOps 模板 |
| `observability/` | 33—36；Prometheus/Grafana/Alertmanager/Collector 和可选插桩 |
| `security/` | 42—44；合成扫描例外与离线工作负载门禁，不是真实安全扫描 |
| `ci/gitlab-ci.yml.example` | 49；专用临时 Runner 上的校验迁移模板 |
| `extensions/` | 54、56；SQLite 幂等消费者和本地规则评测，不连接真实队列或模型 |
| 教程源码 `tools/scaffold_service.py` | 46；生成带元数据的教学基线，拒绝覆盖已有目录 |

本次 Python 测试合计 16 项：12 项 API 与 4 项本地事务测试。更详细的离线检查见[验证记录](verification.html)。可选示例所需额外依赖、身份、环境和版本写在对应目录 README 与章节中，不要求一次启动所有组件。

当前只有完整教学基线，没有逐章起终点快照。先保存自己的起点提交，再记录每章修改与结果；priority 功能作为现有案例分析，status 过滤作为综合项目独立实现。生产仍需认证授权、可追溯制品、真实恢复、外部告警与目标环境验收。
