"""Check actual generated routes, fragments, downloads and source completeness."""
from html.parser import HTMLParser
from pathlib import Path, PurePosixPath
from urllib.parse import unquote, urlsplit
import json
import posixpath
import re
import zipfile

ROOT = Path(__file__).resolve().parents[1]
DIST = ROOT / 'dist'


class Document(HTMLParser):
    def __init__(self, text):
        super().__init__(convert_charrefs=True)
        self.links, self.ids, self.h1, self.main = [], set(), 0, 0
        self.duplicate_ids = []
        self.feed(text)

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if 'id' in attrs:
            if attrs['id'] in self.ids:
                self.duplicate_ids.append(attrs['id'])
            self.ids.add(attrs['id'])
        if tag == 'h1': self.h1 += 1
        if tag == 'main': self.main += 1
        for attribute in ('href', 'src'):
            if attrs.get(attribute): self.links.append(attrs[attribute])


def check_tree(files, label):
    errors = []
    docs = {name: Document(data.decode('utf-8')) for name, data in files.items() if name.endswith('.html')}
    checked = 0
    for name, doc in docs.items():
        if doc.h1 != 1: errors.append(f'{label}/{name}: expected one H1')
        if not name.endswith('404.html') and doc.main != 1: errors.append(f'{label}/{name}: expected one main')
        if doc.duplicate_ids: errors.append(f'{label}/{name}: duplicate IDs {doc.duplicate_ids}')
        for link in doc.links:
            parsed = urlsplit(link)
            if parsed.scheme or parsed.netloc: continue
            target = posixpath.normpath(posixpath.join(posixpath.dirname(name), unquote(parsed.path))) if parsed.path else name
            if target not in files:
                errors.append(f'{label}/{name}: missing {link}')
            elif parsed.fragment and target in docs and unquote(parsed.fragment) not in docs[target].ids:
                errors.append(f'{label}/{name}: missing fragment {link}')
            checked += 1
    return errors, len(docs), checked


files = {str(path.relative_to(DIST)): path.read_bytes() for path in DIST.rglob('*') if path.is_file()}
errors, pages, links = check_tree(files, 'dist')
catalog = json.loads((ROOT / 'content/catalog.json').read_text())
published = [c for c in catalog['chapters'] if c['exists']]
if len(catalog['chapters']) != 48 or len(catalog['electives']) != 8:
    errors.append('Catalog does not match the 48 + 8 specification')
for chapter in published:
    body = (ROOT / 'content/chapters' / (chapter['id'] + '.md')).read_text()
    if body.count('\n## ') < 5 or len(re.findall(r'[\u4e00-\u9fff]', body)) < 1000:
        errors.append(f"Chapter {chapter['id']} is incomplete")
published_electives = [c for c in catalog['electives'] if c.get('exists')]
for chapter in published_electives:
    body = (ROOT / 'content/electives' / (chapter['id'] + '.md')).read_text()
    if body.count('\n## ') < 5 or len(re.findall(r'[\u4e00-\u9fff]', body)) < 1000:
        errors.append(f"Elective {chapter['id']} is incomplete")

zip_counts = {}
for path in sorted((DIST / 'downloads').glob('*.zip')):
    with zipfile.ZipFile(path) as archive:
        if archive.testzip(): errors.append(f'Corrupt archive: {path.name}')
        names = archive.namelist()
        zip_counts[path.name] = len(names)
        for name in names:
            parts = PurePosixPath(name).parts
            if ({'..', '.env', '.git', '.venv', '.lab', 'backups', '__pycache__', '.terraform', 'inventory.local.ini'}.intersection(parts)
                    or any(p.startswith('.venv') for p in parts) or '.tfstate' in name or name.endswith('.tfplan')):
                errors.append(f'Unwanted local data in {path.name}: {name}')
        if path.name == 'ticketdesk.zip':
            for required in ('app/main.py', 'migrations/001-create-tickets.sql', '.github/workflows/ci.yml', 'scripts/lab.py', 'requirements.txt'):
                if 'ticketdesk/' + required not in names: errors.append(f'Project archive missing {required}')
        if path.name == 'devops-guide-deploy.zip':
            exported = {n.removeprefix('devops-guide/'): archive.read(n) for n in names}
            more_errors, exported_pages, exported_links = check_tree(exported, 'export')
            errors.extend(more_errors)

if len(zip_counts) != 5: errors.append('Expected five downloadable archives')
report = {'content_version': json.loads((ROOT / 'package.json').read_text())['version'], 'date': '2026-09-20', 'published_chapters': len(published),
          'published_electives': len(published_electives), 'planned_main_chapters': 48-len(published), 'planned_electives': 8-len(published_electives),
          'html_pages': pages, 'local_links_checked': links,
          'download_archive_entries': zip_counts, 'export_links_checked': exported_links if 'exported_links' in locals() else 0,
          'errors': errors, 'browser_qa': 'not_executed', 'container_integration': 'not_executed'}
(ROOT / 'validation').mkdir(exist_ok=True)
(ROOT / 'validation/site-check.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(report, ensure_ascii=False, indent=2))
raise SystemExit(bool(errors))
