import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
let module;
try { module=await import('marked'); }
catch(error) {
  const deps=process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES;
  if(!deps) throw error;
  module=await import(pathToFileURL(path.join(deps,'marked/lib/marked.esm.js')));
}
const {marked}=module;
const read=p=>fs.readFileSync(path.join(root,p),'utf8');
const escape=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const spec=read('spec/devops-chinese-tutorial-spec-v0.1.md');
const partTitles=['认识交付全流程','Linux、网络与自动化','Git、测试与 CI','容器与可追溯制品','第一次交付与恢复','云与基础设施即代码','Kubernetes 应用运行','GitOps 与集群交付','可观测性与诊断','SRE 与数据可靠性','安全与软件供应链','团队、平台与综合验收'];
const chapters=[...spec.matchAll(/^\| 第 (\d{2}) 章：([^|]+)\|([^|]+)\|([^|]+)\|$/gm)].map(m=>({id:m[1],title:m[2].trim(),scope:m[3].trim(),outcome:m[4].trim(),part:Math.ceil(Number(m[1])/4),slug:'chapter-'+m[1],exists:fs.existsSync(path.join(root,'content/chapters',m[1]+'.md'))}));
const electives=[...spec.matchAll(/^\| 专题 (\d{2})：([^|]+)\|([^|]+)\|([^|]+)\|$/gm)].map(m=>({id:m[1],title:m[2].trim(),scope:m[3].trim(),outcome:m[4].trim(),elective:true,slug:'elective-'+m[1],exists:fs.existsSync(path.join(root,'content/electives',m[1]+'.md'))}));
if(chapters.length!==48||electives.length!==8) throw Error('Expected specification catalog: 48 main chapters + 8 electives');
const published=[...chapters,...electives].filter(c=>c.exists);
const utility=[['project','配套项目与资料'],['answers','练习答案与验收提示'],['glossary','术语与概念对照'],['troubleshooting','故障速查'],['roadmap','完整学习路线'],['verification','版本与验证'],['deploy','放到个人网站']];
const topIcon='<span class="brand-mark" aria-hidden="true"><i></i><i></i><i></i></span>';
const favicon='data:image/svg+xml,'+encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><rect width="32" height="32" rx="7" fill="#2454dc"/><path d="M8 9h7v6H8zm9 8h7v6h-7z" fill="white"/><path d="M18 10h5v5M9 18v5h5" fill="none" stroke="#8fe3f0" stroke-width="2"/></svg>');
const chapterLink=(c,active)=>`<a href="${c.slug}.html" class="chapter-link ${c.slug===active?'active':''}" ${c.slug===active?'aria-current="page"':''}><span>${c.id}</span>${escape(c.title)}</a>`;
function nav(active) {
  const parts=partTitles.map((title,i)=>{
    const cs=chapters.filter(c=>c.part===i+1&&c.exists);
    if(!cs.length) return '';
    const open=cs.some(c=>c.slug===active)||(active==='index'&&i===0);
    return `<details class="nav-part" ${open?'open':''}><summary><span class="part-number">${String(i+1).padStart(2,'0')}</span>${title}</summary>${cs.map(c=>chapterLink(c,active)).join('')}</details>`;
  }).join('');
  return `<nav class="sidebar" id="course-nav" aria-label="课程目录"><a class="home-link ${active==='index'?'active':''}" href="index.html">全书导读</a><div class="nav-label">主线课程 <span>${chapters.filter(c=>c.exists).length} 章正文</span></div>${parts}<div class="nav-label">按需拓展</div><details class="nav-part" ${active.startsWith('elective-')?'open':''}><summary><span class="part-number">＋</span>8 个场景专题</summary>${electives.filter(c=>c.exists).map(c=>chapterLink(c,active)).join('')}</details><div class="nav-label">查阅与实战</div>${utility.map(([slug,title])=>`<a class="utility-link ${active===slug?'active':''}" href="${slug}.html">${title}</a>`).join('')}<div class="sidebar-note">从基础交付到运行治理<br><a href="roadmap.html">查看完整路线与阶段验收 →</a></div></nav>`;
}
function renderMarkdown(md) {
  let html=marked.parse(md,{gfm:true}); const toc=[]; let i=0;
  html=html.replace(/<h([23])>([\s\S]*?)<\/h\1>/g,(_,level,label)=>{
    const id='section-'+(++i);toc.push({id,level:Number(level),label:label.replace(/<[^>]*>/g,'')});
    return `<h${level} id="${id}">${label}<a class="heading-link" href="#${id}" aria-label="本节链接">#</a></h${level}>`;
  });
  html=html.replace(/<table>/g,'<div class="table-scroll" tabindex="0"><table>').replace(/<\/table>/g,'</table></div>');
  return {html,toc};
}
const tocHtml=toc=>toc.map(t=>`<a class="toc-level-${t.level}" href="#${t.id}">${t.label}</a>`).join('');
function page({slug,title,md,chapter=null,custom=''}) {
  const stripped=md.replace(/^# .+\n+/,''); const {html,toc}=renderMarkdown(stripped);
  const description=(stripped.split('\n\n').find(p=>p&&!p.startsWith('#')&&!p.startsWith('<'))||title).replace(/[*`\[\]]/g,'').slice(0,150);
  const index=chapter?published.findIndex(c=>c.id===chapter.id):-1;
  const prev=chapter?published[index-1]:null, next=chapter?published[index+1]:null;
  const group=chapter?.elective?'选修专题':partTitles[(chapter?.part||1)-1];
  const identity=chapter?(chapter.elective?`专题 ${chapter.id}`:`第 ${chapter.id} 章`):'';
  const eyebrow=chapter?(chapter.elective?`ELECTIVE ${chapter.id} <span>·</span> 场景拓展`:`CHAPTER ${chapter.id} <span>·</span> 第 ${chapter.part} 篇`):'DEVOPS HANDBOOK';
  const markup=`<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${escape(title)} · DevOps 实战手册</title><meta name="description" content="${escape(description)}"><meta name="theme-color" content="#102040"><link rel="icon" type="image/svg+xml" href="${favicon}"><link rel="stylesheet" href="assets/reader.css"><script defer src="assets/search-data.js"></script><script defer src="assets/reader.js"></script></head><body data-page="${slug}"><a class="skip-link" href="#main">跳到正文</a><header class="topbar"><button class="menu-button icon-button" id="menu-toggle" aria-label="展开章节目录" aria-controls="course-nav" aria-expanded="false">☰</button><a href="index.html" class="brand">${topIcon}<span>DevOps <b>实战手册</b></span></a><span class="edition">完整阅读版</span><button class="search-trigger" id="search-open"><span>搜索章节、命令、问题</span><kbd>⌘ / Ctrl K</kbd></button><a class="personal-link" href="https://zhangjian94cn.top/" rel="noopener">个人主页 ↗</a></header>${nav(slug)}<button id="nav-shade" class="nav-shade" aria-label="关闭章节目录" hidden></button><div class="reading-layout"><main id="main" class="article" tabindex="-1"><div class="breadcrumb"><a href="index.html">全书导读</a><span>/</span>${chapter?`<span>${group}</span><span>/</span><span>${identity}</span>`:`<span>${escape(title)}</span>`}</div><div class="chapter-eyebrow">${eyebrow}<span class="version-label">v0.3 阅读版</span></div><h1>${escape(title)}</h1>${chapter?`<div class="chapter-outcome"><strong>学习目标</strong><span>${escape(chapter.outcome)}</span></div>`:''}${toc.length?`<details class="mobile-toc"><summary>本页目录</summary>${tocHtml(toc)}</details>`:''}${slug==='roadmap'?'':custom}<div class="prose">${html}</div>${slug==='roadmap'?custom:''}${chapter?`<nav class="chapter-pagination" aria-label="章节翻页"><a href="${prev?prev.slug+'.html':'index.html'}"><small>← 上一篇</small><strong>${escape(prev?prev.title:'全书导读')}</strong></a><a href="${next?next.slug+'.html':'roadmap.html'}"><small>${next?(next.elective?'选修专题 →':'下一章 →'):'学习路线 →'}</small><strong>${escape(next?next.title:'回顾全书与阶段成果')}</strong></a></nav>`:''}<footer class="article-footer"><span>DevOps 实战手册 · 48 章主线 + 8 个专题</span><a href="verification.html">版本与实验验证范围</a><button class="text-button print-button">打印本页</button></footer></main><aside class="page-toc" aria-label="本页目录"><div>本页目录</div>${tocHtml(toc)}<a href="#main" class="back-top">回到顶部 ↑</a><div class="toc-download"><span>边读边实践</span><a href="downloads/ticketdesk.zip" download>下载工单示例 ↗</a><a href="project.html">查看使用说明</a></div></aside></div><dialog id="search-dialog" aria-labelledby="search-heading"><div class="search-head"><label id="search-heading" for="search-input">搜索教程</label><button class="icon-button" id="search-close" aria-label="关闭搜索">×</button></div><input id="search-input" type="search" placeholder="试试：回滚、Kubernetes、SLO、幂等" autocomplete="off"><p class="search-hint" id="search-status" role="status">搜索正文、专题与参考页。Esc 关闭。</p><div id="search-results"></div></dialog><div id="copy-notice" class="copy-notice" role="status" hidden></div></body></html>`;
  fs.mkdirSync(path.join(root,'dist/assets'),{recursive:true});
  fs.writeFileSync(path.join(root,'dist',slug+'.html'),markup);
  return {slug,title,text:stripped.replace(/^```.*$/gm,' ').replace(/<[^>]*>/g,' ').replace(/[#*`|>]/g,' ').replace(/\s+/g,' ').trim(),chapter:chapter?.id||null,elective:!!chapter?.elective};
}
const search=[];
for(const c of published) search.push(page({slug:c.slug,title:c.title,md:read(`content/${c.elective?'electives':'chapters'}/${c.id}.md`),chapter:c}));
for(const [slug,title] of [['index','从第一次提交到可靠交付'],...utility]) {
  let custom='';
  if(slug==='index') {
    const stages=[['01','基础交付','第 01—20 章','chapter-01'],['02','云与集群','第 21—32 章','chapter-21'],['03','运行、安全与团队','第 33—48 章','chapter-33'],['＋','场景拓展','专题 49—56','elective-49']];
    custom=`<div class="start-actions"><a class="primary-button" href="chapter-01.html">从第 01 章开始 <span>→</span></a><a class="secondary-button" href="project.html">运行配套项目</a></div><div class="journey-strip">${stages.map(([id,t,range,target])=>`<a href="${target}.html"><span>${id}</span><strong>${t}</strong><small>${range}</small></a>`).join('')}</div>`;
  }
  if(slug==='roadmap') custom=`<div class="roadmap-grid">${partTitles.map((t,i)=>`<section class="roadmap-part" id="part-${i+1}"><div class="roadmap-part-head"><span>${String(i+1).padStart(2,'0')}</span><h2>${t}</h2><em>${chapters.filter(c=>c.part===i+1).every(c=>c.exists)?'正文已收录':'编写中'}</em></div>${chapters.filter(c=>c.part===i+1).map(c=>`<div class="roadmap-chapter"><span>${c.id}</span><div>${c.exists?`<a href="${c.slug}.html">${escape(c.title)}</a>`:`<strong>${escape(c.title)}</strong>`}<p>${escape(c.scope)}</p></div></div>`).join('')}</section>`).join('')}</div><section class="electives"><h2>8 个选修专题</h2>${electives.map(e=>`<details><summary>${e.id} · ${escape(e.title)}</summary><p>${escape(e.scope)}</p><p><strong>目标产物：</strong>${escape(e.outcome)}</p>${e.exists?`<p><a href="${e.slug}.html">阅读本专题 →</a></p>`:'<p>编写中</p>'}</details>`).join('')}</section>`;
  search.push(page({slug,title,md:read(`content/pages/${slug}.md`),custom}));
}
for(const name of ['reader.css','reader.js']) fs.copyFileSync(path.join(root,'assets',name),path.join(root,'dist/assets',name));
fs.writeFileSync(path.join(root,'dist/assets/search-data.js'),'window.DEVOPS_SEARCH='+JSON.stringify(search).replace(/</g,'\\u003c')+';\n');
fs.writeFileSync(path.join(root,'dist/404.html'),'<!doctype html><html lang="zh-CN"><meta charset="utf-8"><title>页面未找到 · DevOps 实战手册</title><h1>没有找到这个页面</h1><p>请从教程首页重新选择章节。</p><a href="index.html">返回教程首页</a></html>');
fs.writeFileSync(path.join(root,'content/catalog.json'),JSON.stringify({chapters,electives,parts:partTitles},null,2)+'\n');
console.log(JSON.stringify({chapters:chapters.filter(c=>c.exists).length,electives:electives.filter(c=>c.exists).length,pages:search.length}));
