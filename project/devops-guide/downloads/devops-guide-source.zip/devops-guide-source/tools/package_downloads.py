"""Package reader assets without local state, credentials or recursive archives."""
from pathlib import Path
import json
import re
import zipfile

ROOT = Path(__file__).resolve().parents[1]
DIST = ROOT / 'dist'
DOWNLOADS = DIST / 'downloads'
DOWNLOADS.mkdir(parents=True, exist_ok=True)
EXCLUDED = {'.git', '.venv', 'node_modules', '__pycache__', '.pytest_cache',
            '.env', '.lab', 'backups', '.sites-runtime', '.openai', '.terraform', 'inventory.local.ini'}


def eligible(path):
    return (path.is_file() and not path.is_symlink() and not EXCLUDED.intersection(path.parts)
            and not any(part.startswith('.venv') for part in path.parts)
            and '.tfstate' not in path.name and path.suffix not in {'.pyc', '.dump', '.tfplan'})


def write_file(archive, path, name, transform=None):
    data = path.read_bytes()
    if transform:
        data = transform(data)
    info = zipfile.ZipInfo(str(name).replace('\\', '/'), date_time=(2026, 9, 20, 0, 0, 0))
    info.compress_type = zipfile.ZIP_DEFLATED
    info.external_attr = 0o644 << 16
    archive.writestr(info, data)


def create(name, directories, prefix):
    with zipfile.ZipFile(DOWNLOADS / name, 'w') as archive:
        for directory in directories:
            for path in sorted((ROOT / directory).rglob('*')):
                if eligible(path):
                    rel = path.relative_to(ROOT / directory) if len(directories) == 1 else path.relative_to(ROOT)
                    write_file(archive, path, Path(prefix) / rel)


create('ticketdesk.zip', ['examples/ticketdesk'], 'ticketdesk')
create('templates.zip', ['templates'], 'templates')
create('devops-guide-markdown.zip', ['content', 'spec'], 'devops-guide-markdown')
source_folders = ['content', 'spec', 'assets', 'tools', 'templates', 'examples', 'validation']
with zipfile.ZipFile(DOWNLOADS / 'devops-guide-source.zip', 'w') as archive:
    for directory in source_folders:
        for path in sorted((ROOT / directory).rglob('*')):
            if eligible(path):
                write_file(archive, path, Path('devops-guide-source') / path.relative_to(ROOT))
    for name in ['README.md', 'VALIDATION.md', 'package.json', 'package-lock.json', '.gitignore']:
        path = ROOT / name
        if path.exists():
            write_file(archive, path, Path('devops-guide-source') / name)


def remove_self_download(data):
    """The unpacked edition cannot contain an archive recursively containing itself."""
    text = data.decode('utf-8')
    text = re.sub(r'<a\b[^>]*href="downloads/devops-guide-deploy\.zip"[^>]*>(.*?)</a>',
                  r'<span>\1（当前解压版本）</span>', text, flags=re.S)
    return text.encode('utf-8')


deployment = DOWNLOADS / 'devops-guide-deploy.zip'
with zipfile.ZipFile(deployment, 'w') as archive:
    for path in sorted(DIST.rglob('*')):
        if eligible(path) and path != deployment:
            transform = remove_self_download if path.suffix == '.html' else None
            write_file(archive, path, Path('devops-guide') / path.relative_to(DIST), transform)
exports = ROOT / 'exports'
exports.mkdir(exist_ok=True)
version=json.loads((ROOT / 'package.json').read_text())['version']
export_name=f'devops-guide-v{version}.zip'
(exports / export_name).write_bytes(deployment.read_bytes())
print(f'Created 5 reader downloads and exports/{export_name}')
