"""Offline example checks. Does not contact Docker, a cluster, cloud or a model provider."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import yaml

ROOT = Path(__file__).resolve().parents[1]
PROJECT = ROOT / 'examples/ticketdesk'
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--helm', type=Path)
parser.add_argument('--kubectl', type=Path)
args = parser.parse_args()
checks = []


def run(name, command, expected=0, cwd=PROJECT):
    result = subprocess.run([str(x) for x in command], cwd=cwd, capture_output=True, text=True)
    passed = result.returncode == expected
    checks.append({'name': name, 'passed': passed, 'exit_code': result.returncode,
                   'expected_exit_code': expected, 'output': (result.stdout+result.stderr).strip()})
    if not passed:
        raise RuntimeError(f'{name} failed: {result.stdout} {result.stderr}')
    return result.stdout


def record(name, details):
    checks.append({'name': name, 'passed': True, 'details': details})


with tempfile.TemporaryDirectory(prefix='devops-offline-') as folder:
    scratch = Path(folder)
    run('Python compilation', [sys.executable, '-m', 'compileall', '-q', 'app', 'scripts', 'security', 'extensions', 'tests'])
    run('Workload allowed fixture', [sys.executable,'security/check_workload.py','security/fixtures/workload-allowed.yaml','--allowed-prefix','ghcr.io/learning-team/'])
    run('Workload denied fixture', [sys.executable,'security/check_workload.py','security/fixtures/workload-denied.yaml','--allowed-prefix','ghcr.io/learning-team/'], 1)
    scan_base=[sys.executable,'security/evaluate_scan.py','security/fixtures/scan-synthetic.json','--expected-artifact','lab://synthetic-ticketdesk','--as-of','2026-09-20']
    run('Expired scan exception denied', scan_base+['--exceptions','security/fixtures/exception-expired.json'],1)
    exception=json.loads((PROJECT/'security/fixtures/exception-expired.json').read_text())
    exception[0]['expires']='2026-09-21'
    active=scratch/'active.json';active.write_text(json.dumps(exception))
    run('Scoped active synthetic exception accepted',scan_base+['--exceptions',active])
    missing=scratch/'missing.json';missing.write_text(json.dumps({'SchemaVersion':2,'ArtifactName':'lab://synthetic-ticketdesk'}))
    run('Missing scan results denied',[sys.executable,'security/evaluate_scan.py',missing,'--expected-artifact','lab://synthetic-ticketdesk'],1)
    run('Idempotency local demo',[sys.executable,'-m','extensions.async_demo'])
    ai=[sys.executable,'-m','extensions.ai_demo']
    run('AI rule stub baseline',ai+['--bundle','extensions/ai_bundle.json','--cases','extensions/ai_cases.jsonl'])
    bundle=json.loads((PROJECT/'extensions/ai_bundle.json').read_text())
    cases=[json.loads(line) for line in (PROJECT/'extensions/ai_cases.jsonl').read_text().splitlines()]
    cases[0]['expected']='account'
    changed=scratch/'cases.jsonl';changed.write_text('\n'.join(json.dumps(c,ensure_ascii=False) for c in cases)+'\n')
    run('AI dataset identity mismatch denied',ai+['--bundle','extensions/ai_bundle.json','--cases',changed],1)
    bundle['dataset_sha256']=hashlib.sha256(changed.read_bytes()).hexdigest()
    bad_bundle=scratch/'bundle.json';bad_bundle.write_text(json.dumps(bundle))
    run('AI quality regression denied',ai+['--bundle',bad_bundle,'--cases',changed],1)
    cases[0]['expected']='unknown-label'
    changed.write_text('\n'.join(json.dumps(c,ensure_ascii=False) for c in cases)+'\n')
    bundle['dataset_sha256']=hashlib.sha256(changed.read_bytes()).hexdigest();bad_bundle.write_text(json.dumps(bundle))
    run('AI invalid expected label denied',ai+['--bundle',bad_bundle,'--cases',changed],1)
    output=scratch/'service'
    scaffold=[sys.executable,ROOT/'tools/scaffold_service.py','--name','support-api','--owner','support-team','--output',output]
    run('Service scaffold generated',scaffold)
    original=(output/'service-catalog.json').read_bytes()
    run('Service scaffold overwrite denied',scaffold,2)
    assert (output/'service-catalog.json').read_bytes()==original
    assert not any(p.name in ('.env','.lab','.terraform') or '.tfstate' in p.name for p in output.rglob('*'))
    record('Scaffold preserved target and excluded local state','Verified generated metadata unchanged after rejected overwrite')
    yaml_count=0
    for file in PROJECT.rglob('*'):
        if not file.is_file() or not (file.suffix in ('.yaml','.yml') or file.name.endswith('.yml.example')):
            continue
        if 'helm/ticketdesk/templates' in file.as_posix(): continue
        list(yaml.safe_load_all(file.read_text()));yaml_count+=1
    record('YAML syntax',{'files':yaml_count,'boundary':'Parsing only; no API, Ansible or CI service execution'})
    if args.helm:
        version=run('Helm version',[args.helm,'version','--short'])
        run('Helm lint',[args.helm,'lint',PROJECT/'helm/ticketdesk'])
        rendered=run('Helm render',[args.helm,'template','sample',PROJECT/'helm/ticketdesk','--namespace','ticketdesk-stage'])
        docs=list(yaml.safe_load_all(rendered));assert len(docs)==2
        run('Helm missing Secret value denied',[args.helm,'template','sample',PROJECT/'helm/ticketdesk','--set','existingSecret='],1)
    if args.kubectl:
        run('kubectl client version',[args.kubectl,'version','--client','-o','json'])
        for env,replicas,identity in [('dev',1,'development'),('stage',2,'staging')]:
            rendered=run('Kustomize '+env,[args.kubectl,'kustomize',PROJECT/'k8s/overlays'/env])
            docs=list(yaml.safe_load_all(rendered));assert len(docs)==4
            assert all(d['metadata']['namespace']=='ticketdesk-'+env for d in docs)
            deployment=next(d for d in docs if d['kind']=='Deployment')
            config=next(d for d in docs if d['kind']=='ConfigMap')
            service=next(d for d in docs if d['kind']=='Service')
            assert deployment['spec']['replicas']==replicas and config['data']['ENVIRONMENT']==identity
            labels=deployment['spec']['template']['metadata']['labels']
            assert all(labels.get(k)==v for k,v in service['spec']['selector'].items())
        record('Kustomize environment and Service selectors','dev/stage namespaces, replicas, configuration and endpoint selectors match')

report={'date':'2026-09-20','mode':'offline','checks':checks,'all_passed':all(c['passed'] for c in checks),
        'not_executed':['Docker/Compose','PostgreSQL','cloud','OpenTofu provider init/apply','Ansible remote execution','Kubernetes API/runtime','Argo CD','telemetry collection','real scanners/signatures','hosted CI','real model calls']}
(ROOT/'validation/offline-examples.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'checks':len(checks),'all_passed':report['all_passed'],'yaml_files':yaml_count}))
