"""Generate a local teaching baseline; does not provision or register external resources."""
import argparse
import json
from pathlib import Path
import re
import shutil

ROOT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--name', required=True)
parser.add_argument('--owner', required=True)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
for value in (args.name, args.owner):
    if not re.fullmatch(r'[a-z][a-z0-9-]{1,39}', value):
        parser.error('name and owner must be 2–40 lowercase letters, numbers or hyphens, starting with a letter')
target = args.output.resolve()
source = ROOT / 'examples/ticketdesk'
if target.exists() or target == ROOT or source in target.parents:
    parser.error('output must be a new directory outside the template source')
shutil.copytree(source, target, ignore=shutil.ignore_patterns(
    '.env', '.lab', '.venv*', '__pycache__', '*.pyc', '.pytest_cache', 'backups',
    '.terraform', '*.tfstate*', '*.tfplan', 'inventory.local.ini'))
(target / 'service-catalog.json').write_text(json.dumps({
    'name': args.name, 'owner': args.owner, 'template': 'ticketdesk-teaching-0.3.0',
    'profile': 'python-http-postgresql', 'external_registration': False,
    'rename_required': ['TicketDesk application and metrics names', 'Kubernetes and GitOps resource names', 'registry and repository placeholders'],
    'production_review': 'Required: authentication, environment validation, ownership, recovery, alerts'
}, indent=2) + '\n')
print(f'Created teaching baseline at {target}; review service-catalog.json before adapting it.')
