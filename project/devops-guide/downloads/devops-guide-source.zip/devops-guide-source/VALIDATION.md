# v0.3 验证记录

日期：2026-09-20。只记录本次实际执行的结果；预期行为和未执行项单列。

## Python 与本地示例

- Python 3.12.14；FastAPI 0.141.1；pytest 9.1.1。
- 在 `examples/ticketdesk/` 执行 `../../.venv/bin/python -m pytest -q`：16 passed，2 warnings，0.31s。
- 其中 12 项为替换数据库仓储的 API/指标测试；4 项为 SQLite 本地幂等事务测试，覆盖重复、提交前失败回滚、同 ID 不同内容、未知 schema。
- 两项提示来自 Starlette 的 httpx 及 anyio 测试接口弃用；未忽略或伪称消除。
- 执行 `tools/check_examples.py`：23 项离线检查全部符合预期，36 份 YAML 可解析，细节见 `validation/offline-examples.json`。
- 离线门禁包括合规/违规工作负载、过期/有效合成例外、缺失扫描结果；AI 桩包括正常、数据集摘要不符、质量下降、非法标签；脚手架包括生成、拒绝覆盖和排除本地状态。
- Helm 3.19.0 lint、template 和缺失 existingSecret 负例符合预期。kubectl 1.34.0 仅用于本地 Kustomize 渲染，dev/stage 的命名空间、副本、配置与 Service selector 检查通过。
- Helm 与 kubectl 二进制从官方分发下载并按对应校验文件检查；版本不代表生产推荐。
- 可选 OpenTelemetry 依赖通过 pip dry-run resolver 在基础依赖约束下解析为确切版本清单；没有安装镜像或执行真实插桩。
- Python 编译检查通过。YAML 解析不是 Ansible、GitLab、Kubernetes API 或运行语义的全量验证。

## 网站

- `node tools/build.mjs` 生成 48 章、8 专题、8 个参考/导读页面及 404 页面。
- `node --check assets/reader.js` 和 `node --check tools/build.mjs` 检查可解析性。
- `tools/package_downloads.py` 生成 5 份 ZIP，并导出可独立部署目录。
- `tools/check_site.py` 检查实际页面、锚点、附件、解压后的部署包与源文完整性，结果见 `validation/site-check.json`。
- 尚未运行浏览器视觉和交互自动化。静态项目没有受支持的内部预览服务器；未把源码检查写成视觉测试。

## 外部来源

Actions 引用已核对并固定：checkout v6 `d23441a48e516b6c34aea4fa41551a30e30af803`；setup-python v6 `ece7cb06caefa5fff74198d8649806c4678c61a1`。选定 Docker provider、Prometheus、Grafana 与 Collector 标签存在性经官方仓库核对。官方资料按章节链接，未将版本存在当作集成通过。

## 未执行的环境检查

- Dockerfile 与 Compose、真实 PostgreSQL 事务/迁移/锁/备份/恢复。
- OpenTofu provider 初始化、计划与 apply；Ansible SSH、systemd 和远端幂等。
- Kubernetes 调度/探针/网络/存储/策略、Gateway、Argo CD、HPA、PDB、网格。
- Prometheus/Grafana/Collector 真实运行、OTel 插桩、外部通知、压测和 SLO 达标。
- GitHub/GitLab 托管 CI、registry 推送、真实扫描/SBOM/签名和准入。
- 云资源、自托管内网、Java VM 改造、真实消息 broker 与模型调用。
- 旧二进制和新数据库共存、跨架构复现、独立读者复现与浏览器验收。

## 已知限制

应用无用户认证、无高可用、列表上限 100，使用短连接和进程内指标。基础镜像是候选标签；真实验证后应锁 digest。`.lab/release.json` 只记录最近成功镜像，恢复不撤销数据库迁移。新统计直方图不是多进程聚合系统。

没有逐章起终点代码快照。priority 已在基线中，status 过滤留作独立项目。异步与 AI 示例未接入 HTTP API；AI 为本地规则桩。GitLab 文件只迁移校验段；云、网格和传统应用按前提提供案例与验收。每项边界在对应正文中说明。
