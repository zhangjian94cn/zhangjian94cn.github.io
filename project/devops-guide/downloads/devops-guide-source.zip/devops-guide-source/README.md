# DevOps 实战手册

按《DevOps 中文教程 Spec v0.1》组织的中文教程与静态网站。当前 v0.3 完整阅读版包括 48 章主线、8 个专题、练习答案、配套 TicketDesk、11 份工程模板、术语、故障索引与部署说明。

## 阅读与部署

入口为 `dist/index.html`，可放在个人站 `project/devops-guide/`，无需后端。部署包为 `exports/devops-guide-v0.3.0.zip`，源码与读者资料在 `dist/downloads/`。提供个人站接入说明，但未修改 zhangjian94cn.top。

## 维护

使用兼容 marked 17 的 Node 环境（Node 20 或更新版本）和 Python 3：

```bash
npm ci
npm run build
python3 tools/package_downloads.py
npm run check
```

- `content/chapters/`：48 章主线。
- `content/electives/`：49—56 场景专题。
- `content/pages/`：导读、答案、术语、故障与维护说明。
- `spec/`：原始规划依据，保留独立版本。
- `assets/`：阅读布局、菜单、搜索、复制、打印和教学交互。
- `tools/`：生成、打包、静态/离线检查与服务脚手架。
- `examples/ticketdesk/`：可成为独立仓库的教学应用及各阶段示例。
- `templates/`：11 份工程记录模板。

## 验证范围

16 项 Python 测试通过，包括 12 项 API 和 4 项本地幂等事务测试；23 项离线示例检查通过，包括 Helm/Kustomize、门禁正反例、脚手架与 AI 规则桩。真实容器、PostgreSQL、云、集群、托管 CI、采集与签名尚未运行。网站结构与引用检查通过，浏览器视觉及交互待验收。详见 `VALIDATION.md`。

本版正文齐备，不将其等同于完整实验已验收。后续完善以真实环境复现、阶段快照、兼容矩阵与读者试读为重点。配套应用没有认证授权，不直接用于公开生产服务。

## 来源

范围参考 [milanm/DevOps-Roadmap](https://github.com/milanm/DevOps-Roadmap)，正文以连续工单案例原创组织，技术依据在相关章节就近链接。用户提供的 Git 教程参考页最初读取受限，当前界面为独立设计。
